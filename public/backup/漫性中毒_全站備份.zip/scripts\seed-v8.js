/**
 * SEED v8.0 - High Quality Content & Title Fixes
 * 
 * Changes:
 * - REWRITE ALL descriptions (No generic "heated discussion" text)
 * - FIX TITLES: Remove "EP1", ensure full formatting
 * - FIX: "我的正義使者" -> "我的英雄學院外傳：非法英雄"
 * - FIX: "判處勇者刑" description logic
 */

const Database = require('better-sqlite3');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'anime.db');

const articles = [
    {
        slug: 'frieren-s2-ep1',
        title: '《葬送的芙莉蓮》第二季｜北部高原篇',
        excerpt: '芙莉蓮一行人為前往靈魂長眠之地，踏上危險的北部高原，全新旅程展開。',
        image: '/images/anime/frieren-s2.jpg',
        category: '集數更新',
        content: `《葬送的芙莉蓮》第二季正式進入「北部高原篇」！

![葬送的芙莉蓮第二季](/images/anime/frieren-s2.jpg)

## 劇情概要

結束了一級魔法使考試後，芙莉蓮、費倫與修塔爾克三人為了前往勇者辛美爾長眠的「魂靈沉眠之地」（オレオール），必須穿越魔物橫行的北部高原。這趟旅程不僅是空間上的移動，更是芙莉蓮追尋過往記憶、理解人類情感的深度之旅。途中他們將遭遇更強大的魔族，以及形形色色的新舊面孔。

## 製作亮點

由 Madhouse 原班人馬製作，斎藤圭一郎監督繼續執導。本季將維持第一季的高規格作畫與細膩演出，Evan Call 的配樂依然是靈魂所在。

## 播出資訊

日本每週五 23:00 播出，台灣由木棉花代理，各大串流平台同步跟播。`
    },
    {
        slug: 'jjk-culling-ep1',
        title: '《咒術迴戰》死滅迴游篇｜史上最殘酷術師殺戮',
        excerpt: '澀谷事變後的絕望延續，虎杖與伏黑被迫參加互相廝殺的「死滅迴游」。',
        image: '/images/anime/jjk-culling.jpg',
        category: '集數更新',
        content: `《咒術迴戰》第三季「死滅迴游篇」震撼開播！

![咒術迴戰死滅迴游](/images/anime/jjk-culling.jpg)

## 劇情概要

澀谷事變造成日本社會崩壞，羂索更進一步啟動了名為「死滅迴游」的術師生存遊戲。為了拯救姐姐津美紀並解開封印五條悟的獄門疆，虎杖悠仁、伏黑惠以及特級術師乙骨憂太等人，必須主動跳入這場以殺戮換取點數的死亡競賽中。

## 製作亮點

由 MAPPA 傾力製作，本篇章戰鬥密度極高，被視為動畫製作的一大挑戰。預告片中已展現了極具張力的動作場面與獨特的色調風格。

## 播出資訊

台灣每週四深夜更新，各大串流平台同步上架。`
    },
    {
        slug: 'oshi-no-ko-s3-ep1',
        title: '《我推的孩子》第三季｜揭開謊言的電影篇',
        excerpt: '阿奎亞與露比將主演描述母親「星野愛」一生的電影，直面殘酷真相。',
        image: '/images/anime/oshi-no-ko-s3.jpg',
        category: '集數更新',
        content: `《我推的孩子》第三季正式進入原作最高潮的「電影篇」！

![我推的孩子第三季](/images/anime/oshi-no-ko-s3.jpg)

## 劇情概要

為了揭發演藝圈的黑暗並向生父復仇，阿奎亞策劃了一部名為《15年的謊言》的電影，更讓露比飾演母親星野愛。這部電影將赤裸裸地揭露愛的一生、謊言以及被隱藏的過去。演員們必須將自身的真實情感融入演技中，過程充滿了痛苦與掙扎。

## 製作亮點

動畫工房在文戲與情感渲染上一向表現出色，本季將挑戰更深層次的角色心理描寫，是驗證製作實力的關鍵篇章。

## 播出資訊

台灣各大串流平台熱播中。`
    },
    {
        slug: 'fire-force-s3-ep1',
        title: '《炎炎消防隊 參之章》｜大災害的真相與最終決戰',
        excerpt: '第八特殊消防隊迎來最終章，全人類的命運將在火焰中決出勝負。',
        image: '/images/anime/fire-force-s3.jpg',
        category: '集數更新',
        content: `《炎炎消防隊》動畫版終於迎來完結篇「參之章」！

![炎炎消防隊參之章](/images/anime/fire-force-s3.jpg)

## 劇情概要

隨著「傳道者」的計畫進入最終階段，世界各地頻發大災害。森羅日下部與第八特殊消防隊必須解開人體自燃現象的終極謎團，並阻止世界毀滅。森羅作為「柱」的宿命，以及他與弟弟象的關係，都將在此畫下句點。

## 製作亮點

David Production 標誌性的特效作畫在本季火力全開，動作場面的流暢度與衝擊力保證讓觀眾熱血沸騰。

## 播出資訊

每週五深夜播出，台灣由各大串流平台跟播。`
    },
    {
        slug: 'polar-opposites-ep1',
        title: '《相反的你和我》｜正反磁極般的甜蜜戀愛',
        excerpt: '充滿活力的辣妹與沈默寡言的書呆子，性格天差地遠卻意外合拍。',
        image: '/images/anime/polar-opposites.jpg',
        category: '集數更新',
        content: `本季最甜戀愛番《相反的你和我》改編自阿賀澤紅茶的人氣漫畫！

![相反的你和我](/images/anime/polar-opposites.jpg)

## 劇情概要

總是精神飽滿、隨波逐流的鈴木美優，喜歡上了總是沈默寡言、有話直說的谷悠介。雖然兩人的外表與性格看似完全相反，但實際上卻能互補並理解對方。沒有灑狗血的誤會，只有滿滿的直球對決與青春悸動，是一部看了會讓人不自覺微笑的作品。

## 製作亮點

動畫還原了原作獨特的畫風與Q版表情，節奏輕快活潑，完美呈現了高中校園的青澀戀愛氛圍。

## 播出資訊

台灣各大平台每週更新。`
    },
    {
        slug: 'torture-princess-s2-ep1',
        title: '《公主殿下，「拷問」的時間到了》第二季｜屈服於美食吧',
        excerpt: '魔王軍最殘忍的（美食）拷問再次開始，公主今天能守住秘密嗎？',
        image: '/images/anime/torture-princess.jpg',
        category: '集數更新',
        content: `療癒系搞笑番《公主殿下，「拷問」的時間到了》第二季歡樂回歸！

![公主殿下拷問時間](/images/anime/torture-princess.jpg)

## 劇情概要

身為王國騎士團長的公主淪為魔王軍的階下囚，每天都要面對各式各樣的「拷問」——頂級牛排、剛出爐的吐司、蓬鬆的溫泉。公主為了尊嚴（並沒有）總是會在最後一刻屈服於慾望，並洩漏根本無關緊要的國家機密。第二季將帶來更多誘人的美食與荒謬的拷問道具。

## 製作亮點

本季在「美食作畫」上依然下足功夫，深夜觀看絕對是種折磨（肚子餓的意味）。

## 播出資訊

每週二凌晨更新，適合配飯觀看的輕鬆小品。`
    },
    {
        slug: 'medalist-ep1',
        title: '《金牌得主》｜賭上人生的花式滑冰雙人組',
        excerpt: '被放棄的熱血教練與被輕視的天才少女，攜手挑戰冰上的頂點。',
        image: '/images/anime/medalist.jpg',
        category: '集數更新',
        content: `熱血運動番《金牌得主》終於動畫化！

![金牌得主](/images/anime/medalist.jpg)

## 劇情概要

主角明浦路司曾懷抱滑冰夢想卻受挫，如今成為了一名教練。他遇見了雖然擁有極高天賦，卻因為起步太晚而被周遭反對學習滑冰的少女結束祈。同樣被視為「沒有希望」的兩人決定聯手，用熱情與努力打破眾人的偏見，目標是奧運金牌！

## 製作亮點

由 ENGI 製作，花式滑冰的動作場景採用了精細的動態捕捉與手繪修飾，力求展現冰上的速度感與美感。

## 播出資訊

台灣各大平台熱播中。`
    },
    {
        slug: 'mf-ghost-s3-ep1',
        title: '《MF Ghost 燃油車鬥魂》第三季｜決戰真鶴半島',
        excerpt: '承襲《頭文字D》的公路最速傳說，MFG 第三戰技術賽道開跑。',
        image: '/images/anime/mf-ghost-s3.jpg',
        category: '集數更新',
        content: `賽車迷必看！《MF Ghost 燃油車鬥魂》第三季引擎全開！

![MF Ghost 燃油車鬥魂](/images/anime/mf-ghost-s3.jpg)

## 劇情概要

片桐夏向駕駛著馬力劣勢的 Toyota 86，憑藉著驚人的技術在 MFG 賽事中嶄露頭角。第三季來到第三戰「The Peninsula 真鶴」，這是一個充滿急彎與高低差的技術型賽道，對於馬力不足但操控精湛的 86 來說是絕佳的舞台。夏向能否再次創造奇蹟？

## 製作亮點

CG 車輛模組與音效依然是本作強項，尤其是歐陸節拍（Eurobeat）響起的那一刻，絕對讓老粉絲熱血沸騰。

## 播出資訊

每週日深夜更新。`
    },
    {
        slug: 'vigilantes-s2-ep1',
        title: '《我的英雄學院外傳：非法英雄》第二季｜無照英雄的矜持',
        excerpt: '在合法英雄照耀不到的角落，非法英雄們依然在默默守護城市。',
        image: '/images/anime/vigilantes.jpg',
        category: '集數更新',
        content: `《我的英雄學院》官方外傳《非法英雄》第二季好評播出中！

![正義使者第二季](/images/anime/vigilantes.jpg)

## 劇情概要

雖然沒有英雄執照，但灰廻航一以「爬行者」的名義，與師父諾克路士、搭檔波普一同在鳴羽田區進行義警活動。第二季將深入描繪航一「滑行」個性的進化，以及更加危險的敵人「凡人」藥物的擴散。比起本傳的光鮮亮麗，本作更聚焦於社會底層的奮鬥與羈絆。

## 製作亮點

本作的打鬥風格較為街頭、靈活，與本傳的大招互轟有著截然不同的看點。

## 播出資訊

台灣各大平台同步跟播。`
    },
    {
        slug: 'sentenced-ep1',
        title: '《判處勇者刑》｜罪人與英雄的一線之隔',
        excerpt: '為了減刑，前勇者必須率領最惡劣的罪犯部隊，執行必死的魔王處決任務。',
        image: '/images/anime/sentenced.jpg',
        category: '集數更新',
        content: `改編自話題輕小說的暗黑奇幻大作《判處勇者刑》！

![判處勇者刑](/images/anime/sentenced.jpg)

## 劇情概要

札伊德曾是殺死魔王的聖騎士團長，受世人景仰。然而，他後來卻被冠上莫須有的罪名，剝奪了一切榮耀。為了延續生命，他被迫成為「懲罰勇者部隊」的隊長，率領一群同樣被判處「勇者刑」的重刑犯（包括詐欺師、殺人魔等），與不斷復活的魔王軍團進行無止盡的廝殺。這是一個關於絕望、贖罪與扭曲正義的故事。

## 製作亮點

本作以灰暗沈重的色調還原了原作那令人窒息的世界觀，戰鬥場面血腥且殘酷，強烈推薦給喜歡重口味奇幻的觀眾。

## 播出資訊

每週更新，建議家長陪同觀看（誤）。`
    },
    {
        slug: 'darwin-ep1',
        title: '《達爾文事變》｜人與非人的界線',
        excerpt: '半人半猩猩的少年查理，捲入了人類至上主義與激進動物權利團體的恐怖鬥爭。',
        image: '/images/anime/hidden-gems.jpg',
        category: '集數更新',
        content: `榮獲漫畫大賞的社會派鉅作《達爾文事變》終於動畫化！

![達爾文事變](/images/anime/hidden-gems.jpg)

## 劇情概要

查理是人類與黑猩猩混種的「Humanzee」，擁有超越常人的體能與獨特的思維。被人類家庭扶養長大的他，試圖融入高中生活，卻被激進動物解放組織「ALA」盯上，希望能將他拉攏為推翻人類統治的象徵。查理必須在兩個物種的衝突夾縫中，尋找自己的生存之道。

## 製作亮點

本作探討了種族歧視、恐怖主義與生命的定義，劇情深度極高，動作場面也相當俐落寫實。

## 播出資訊

Disney+ 獨家播出。`
    },
    {
        slug: 'hells-paradise-s2-ep1',
        title: '《地獄樂》第二季｜決戰蓬萊仙島',
        excerpt: '畫眉丸與佐切終於抵達島嶼核心，面對掌握不死仙藥秘密的「天仙」。',
        image: '/images/anime/dark-fantasy-rec.jpg',
        category: '集數更新',
        content: `賀來友治原作的《地獄樂》第二季殺進核心篇章！

![地獄樂第二季](/images/anime/dark-fantasy-rec.jpg)

## 劇情概要

為了獲得赦免狀回到愛妻身邊，畫眉丸與處刑人山田淺右衛門佐切深入充滿怪物的神秘島嶼。倖存者們終於集結，並發現了島嶼背後的真相——這裡是被七名長生不老的「天仙」所統治的實驗場。為了奪取仙藥並活著離開，人類必須超越極限，挑戰神一般的存在。

## 製作亮點

MAPPA 繼續操刀，將原作中色彩斑斕卻詭譎恐怖的植物與怪物設計完美重現，打鬥畫面依舊行雲流水。

## 播出資訊

Netflix 獨家播出。`
    },
    {
        slug: 'jojo-sbr-ep1',
        title: '《JOJO的奇妙冒險 飆馬野郎》｜橫越美洲大陸的史詩',
        excerpt: '喬尼·喬斯達與傑洛·齊貝林，為了各自的信念，踏上六千公里的極限賽馬。',
        image: '/images/anime/fate-strange-fake.jpg',
        category: '集數更新',
        content: `萬眾期待！JOJO 系列轉折點第七部《飆馬野郎》動畫化啟動！

![飆馬野郎 JOJO](/images/anime/fate-strange-fake.jpg)

## 劇情概要

1890 年代，一場總獎金高達 5000 萬美元的橫越北美大陸賽馬大賽「SBR」即將展開。天才騎手傑洛·齊貝林使用神秘的「鐵球」迴轉技術，吸引了下半身癱瘓的前天才騎手喬尼·喬斯達的注意。為了尋求重新站起來的希望，喬尼決定追隨傑洛，投身這場充滿陰謀與替身能力的殘酷競賽。

## 製作亮點

馬匹的奔跑動態是動畫界的高難度挑戰，製作組採用了最新的 3D 輔助 2D 技術，力求還原荒木飛呂彥筆下的速度感與魄力。

## 播出資訊

本季開播，JOJO 粉絲絕對不能錯過。`
    },
    {
        slug: 'nube-ep1',
        title: '《靈異教師神眉 2025》｜經典妖怪教師回歸',
        excerpt: '鬼手教師鵺野鳴介回來了！在現代校園中繼續守護學生免受靈異侵擾。',
        image: '/images/anime/seiyuu-rec.jpg',
        category: '集數更新',
        content: `90 年代經典回憶《靈異教師神眉》全新動畫版！

![靈異教師神眉](/images/anime/seiyuu-rec.jpg)

## 劇情概要

童守小學 5 年 3 班的班導師鵺野鳴介（神眉），左手平時戴著黑手套，底下封印著強大的「鬼手」。為了保護學生，他不惜賭上性命與各種妖怪戰鬥。新版動畫不僅重製經典篇章，更加入了符合現代背景的全新原創劇情。

## 製作亮點

新版的人設更加美型，但經典的恐怖氛圍與感人師生情依然原汁原味。

## 播出資訊

每週六晚間播出。`
    },
    {
        slug: 'hanakimi-ep1',
        title: '《花樣少年少女》｜經典女扮男裝校園喜劇',
        excerpt: '為了接近憧憬的跳高選手，瑞稀不惜喬裝進入全是帥哥的男校就讀。',
        image: '/images/anime/game-rec.jpg',
        category: '集數更新',
        content: `少女漫畫聖經《花樣少年少女》首次完整動畫化！

![花樣少年少女](/images/anime/game-rec.jpg)

## 劇情概要

蘆屋瑞稀為了激勵受傷放棄跳高的佐野泉，毅然決然剪短頭髮，偽裝成男生轉入佐野就讀的櫻咲學園。她幸運地成為了佐野的室友，卻每天都要在暴露性別的邊緣試探。充滿青春、友情與心跳加速的校園生活就此展開。

## 製作亮點

重現了當年原作的華麗畫風，集結了豪華聲優陣容來演繹這群個性十足的男校學生。

## 播出資訊

本季熱播中。`
    }
];

async function seed() {
    console.log('🚀 Seeding database with v8 HIGH QUALITY content...');
    const db = new Database(dbPath);

    const updateStmt = db.prepare(`
        UPDATE articles 
        SET title = ?, excerpt = ?, content = ?, category = ?
        WHERE slug = ?
    `);

    for (const article of articles) {
        const result = updateStmt.run(
            article.title,
            article.excerpt,
            article.content,
            article.category,
            article.slug
        );

        if (result.changes > 0) {
            console.log(`✅ Updated: ${article.slug} -> ${article.title}`);
        } else {
            console.log(`⚠️  Article not found: ${article.slug}`);
        }
    }

    console.log('\\n✅ v8 update complete! No more generic content.');
}

seed();
