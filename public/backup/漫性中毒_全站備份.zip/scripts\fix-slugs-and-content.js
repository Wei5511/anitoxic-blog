/**
 * FIX SLUGS AND CONTENT
 * 
 * Problem: DB has old slugs (e.g., 'frieren-ep1') but Seed v8 targeted 'frieren-s2-ep1'.
 * Result: Updates were skipped.
 * Fix: Update the SLUG and CONTENT for the old records.
 */

const Database = require('better-sqlite3');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'anime.db');

const fixes = [
    {
        oldSlug: 'frieren-ep1',
        newSlug: 'frieren-s2-ep1',
        title: '《葬送的芙莉蓮》第二季｜北部高原篇',
        excerpt: '芙莉蓮一行人為前往靈魂長眠之地，踏上危險的北部高原，全新旅程展開。',
        image: '/images/anime/frieren-s2.jpg',
        category: '集數更新',
        content: `《葬送的芙莉蓮》第二季正式進入「北部高原篇」！

![葬送的芙莉蓮第二季](/images/anime/frieren-s2.jpg)

## 劇情概要

結束了一級魔法使考試後，芙莉蓮、費倫與修塔爾克三人為了前往勇者辛美爾長眠的「魂靈沉眠之地」（オレオール），必須穿越魔物橫行的北部高原。這趟旅程不僅是空間上的移動，更是芙莉蓮追尋過往記憶、理解人類情感的深度之旅。途中他們將遭遇更強大的魔族，以及形形色色的新舊面孔。

## 製作亮點

由 Madhouse 原班人馬製作，斎藤圭一郎監督繼續執導。本季將維持第一季的高規格作畫與細膩演出，Evan Call 的配樂依然是靈魂所在。

## 播出資訊

日本每週五 23:00 播出，台灣由木棉花代理，各大串流平台同步跟播。`
    },
    {
        oldSlug: 'jjk-ep1',
        newSlug: 'jjk-culling-ep1',
        title: '《咒術迴戰》死滅迴游篇｜史上最殘酷術師殺戮',
        excerpt: '澀谷事變後的絕望延續，虎杖與伏黑被迫參加互相廝殺的「死滅迴游」。',
        image: '/images/anime/jjk-culling.jpg',
        category: '集數更新',
        content: `《咒術迴戰》第三季「死滅迴游篇」震撼開播！

![咒術迴戰死滅迴游](/images/anime/jjk-culling.jpg)

## 劇情概要

澀谷事變造成日本社會崩壞，羂索更進一步啟動了名為「死滅迴游」的術師生存遊戲。為了拯救姐姐津美紀並解開封印五條悟的獄門疆，虎杖悠仁、伏黑惠以及特級術師乙骨憂太等人，必須主動跳入這場以殺戮換取點數的死亡競賽中。

## 製作亮點

由 MAPPA 傾力製作，本篇章戰鬥密度極高，被視為動畫製作的一大挑戰。預告片中已展現了極具張力的動作場面與獨特的色調風格。

## 播出資訊

台灣每週四深夜更新，各大串流平台同步上架。`
    },
    {
        oldSlug: 'oshi-no-ko-ep1',
        newSlug: 'oshi-no-ko-s3-ep1',
        title: '《我推的孩子》第三季｜揭開謊言的電影篇',
        excerpt: '阿奎亞與露比將主演描述母親「星野愛」一生的電影，直面殘酷真相。',
        image: '/images/anime/oshi-no-ko-s3.jpg',
        category: '集數更新',
        content: `《我推的孩子》第三季正式進入原作最高潮的「電影篇」！

![我推的孩子第三季](/images/anime/oshi-no-ko-s3.jpg)

## 劇情概要

為了揭發演藝圈的黑暗並向生父復仇，阿奎亞策劃了一部名為《15年的謊言》的電影，更讓露比飾演母親星野愛。這部電影將赤裸裸地揭露愛的一生、謊言以及被隱藏的過去。演員們必須將自身的真實情感融入演技中，過程充滿了痛苦與掙扎。

## 製作亮點

動畫工房在文戲與情感渲染上一向表現出色，本季將挑戰更深層次的角色心理描寫，是驗證製作實力的關鍵篇章。

## 播出資訊

台灣各大串流平台熱播中。`
    },
    {
        oldSlug: 'fire-force-ep1',
        newSlug: 'fire-force-s3-ep1',
        title: '《炎炎消防隊 參之章》｜大災害的真相與最終決戰',
        excerpt: '第八特殊消防隊迎來最終章，全人類的命運將在火焰中決出勝負。',
        image: '/images/anime/fire-force-s3.jpg',
        category: '集數更新',
        content: `《炎炎消防隊》動畫版終於迎來完結篇「參之章」！

![炎炎消防隊參之章](/images/anime/fire-force-s3.jpg)

## 劇情概要

隨著「傳道者」的計畫進入最終階段，世界各地頻發大災害。森羅日下部與第八特殊消防隊必須解開人體自燃現象的終極謎團，並阻止世界毀滅。森羅作為「柱」的宿命，以及他與弟弟象的關係，都將在此畫下句點。

## 製作亮點

David Production 標誌性的特效作畫在本季火力全開，動作場面的流暢度與衝擊力保證讓觀眾熱血沸騰。

## 播出資訊

每週五深夜播出，台灣由各大串流平台跟播。`
    },
    {
        oldSlug: 'torture-princess-ep1',
        newSlug: 'torture-princess-s2-ep1',
        title: '《公主殿下，「拷問」的時間到了》第二季｜屈服於美食吧',
        excerpt: '魔王軍最殘忍的（美食）拷問再次開始，公主今天能守住秘密嗎？',
        image: '/images/anime/torture-princess.jpg',
        category: '集數更新',
        content: `療癒系搞笑番《公主殿下，「拷問」的時間到了》第二季歡樂回歸！

![公主殿下拷問時間](/images/anime/torture-princess.jpg)

## 劇情概要

身為王國騎士團長的公主淪為魔王軍的階下囚，每天都要面對各式各樣的「拷問」——頂級牛排、剛出爐的吐司、蓬鬆的溫泉。公主為了尊嚴（並沒有）總是會在最後一刻屈服於慾望，並洩漏根本無關緊要的國家機密。第二季將帶來更多誘人的美食與荒謬的拷問道具。

## 製作亮點

本季在「美食作畫」上依然下足功夫，深夜觀看絕對是種折磨（肚子餓的意味）。

## 播出資訊

每週二凌晨更新，適合配飯觀看的輕鬆小品。`
    },
    {
        oldSlug: 'mf-ghost-ep1',
        newSlug: 'mf-ghost-s3-ep1',
        title: '《MF Ghost 燃油車鬥魂》第三季｜決戰真鶴半島',
        excerpt: '承襲《頭文字D》的公路最速傳說，MFG 第三戰技術賽道開跑。',
        image: '/images/anime/mf-ghost-s3.jpg',
        category: '集數更新',
        content: `賽車迷必看！《MF Ghost 燃油車鬥魂》第三季引擎全開！

![MF Ghost 燃油車鬥魂](/images/anime/mf-ghost-s3.jpg)

## 劇情概要

片桐夏向駕駛著馬力劣勢的 Toyota 86，憑藉著驚人的技術在 MFG 賽事中嶄露頭角。第三季來到第三戰「The Peninsula 真鶴」，這是一個充滿急彎與高低差的技術型賽道，對於馬力不足但操控精湛的 86 來說是絕佳的舞台。夏向能否再次創造奇蹟？

## 製作亮點

CG 車輛模組與音效依然是本作強項，尤其是歐陸節拍（Eurobeat）響起的那一刻，絕對讓老粉絲熱血沸騰。

## 播出資訊

每週日深夜更新。`
    },
    {
        oldSlug: 'vigilantes-ep1',
        newSlug: 'vigilantes-s2-ep1',
        title: '《我的英雄學院外傳：非法英雄》第二季｜無照英雄的矜持',
        excerpt: '在合法英雄照耀不到的角落，非法英雄們依然在默默守護城市。',
        image: '/images/anime/vigilantes.jpg',
        category: '集數更新',
        content: `《我的英雄學院》官方外傳《非法英雄》第二季好評播出中！

![正義使者第二季](/images/anime/vigilantes.jpg)

## 劇情概要

雖然沒有英雄執照，但灰廻航一以「爬行者」的名義，與師父諾克路士、搭檔波普一同在鳴羽田區進行義警活動。第二季將深入描繪航一「滑行」個性的進化，以及更加危險的敵人「凡人」藥物的擴散。比起本傳的光鮮亮麗，本作更聚焦於社會底層的奮鬥與羈絆。

## 製作亮點

本作的打鬥風格較為街頭、靈活，與本傳的大招互轟有著截然不同的看點。

## 播出資訊

台灣各大平台同步跟播。`
    },
    {
        oldSlug: 'hells-paradise-ep1',
        newSlug: 'hells-paradise-s2-ep1',
        title: '《地獄樂》第二季｜決戰蓬萊仙島',
        excerpt: '畫眉丸與佐切終於抵達島嶼核心，面對掌握不死仙藥秘密的「天仙」。',
        image: '/images/anime/dark-fantasy-rec.jpg',
        category: '集數更新',
        content: `賀來友治原作的《地獄樂》第二季殺進核心篇章！

![地獄樂第二季](/images/anime/dark-fantasy-rec.jpg)

## 劇情概要

為了獲得赦免狀回到愛妻身邊，畫眉丸與處刑人山田淺右衛門佐切深入充滿怪物的神秘島嶼。倖存者們終於集結，並發現了島嶼背後的真相——這裡是被七名長生不老的「天仙」所統治的實驗場。為了奪取仙藥並活著離開，人類必須超越極限，挑戰神一般的存在。

## 製作亮點

MAPPA 繼續操刀，將原作中色彩斑斕卻詭譎恐怖的植物與怪物設計完美重現，打鬥畫面依舊行雲流水。

## 播出資訊

Netflix 獨家播出。`
    }
];

async function fix() {
    console.log('🚀 Fixing Slugs and Content...');
    const db = new Database(dbPath);

    const updateStmt = db.prepare(`
        UPDATE articles 
        SET slug = ?, title = ?, excerpt = ?, content = ?, category = ?
        WHERE slug = ?
    `);

    for (const f of fixes) {
        // Try to update the OLD slug record to the NEW slug & Content
        // Note: If NEW slug already exists, this might fail (UNIQUE constraint), 
        // so we should check or DELETE new slug first if it's empty/dup? 
        // But assumedly NEW slug is NOT in DB yet based on dump.

        try {
            const result = updateStmt.run(
                f.newSlug,
                f.title,
                f.excerpt,
                f.content,
                f.category,
                f.oldSlug // The WHERE clause
            );

            if (result.changes > 0) {
                console.log(`✅ Fixed: ${f.oldSlug} -> ${f.newSlug} (${f.title})`);
            } else {
                console.log(`⚠️  Old Slug Not Found: ${f.oldSlug}`);
            }
        } catch (e) {
            console.error(`❌ Error fixing ${f.oldSlug}: ${e.message}`);
        }
    }

    console.log('\\n✅ Fix Complete!');
}

fix();
