import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

// GET /api/articles - List all articles
export async function GET(request) {
  try {
    const db = getDb();
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    let sql = 'SELECT * FROM articles WHERE 1=1';
    const params = [];

    if (category && category !== '全部') {
      sql += ' AND category = ?';
      params.push(category);
    }

    if (search) {
      sql += ' AND (title LIKE ? OR content LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY is_pinned DESC, published_at DESC';

    const articles = db.prepare(sql).all(...params);
    return NextResponse.json({ success: true, data: articles });
  } catch (error) {
    console.error('Database Error:', error);
    return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
  }
}

// POST /api/articles - Create new article
export async function POST(request) {
  try {
    const db = getDb();
    const body = await request.json();
    const { title, slug, content, category, image_url, myvideo_url, is_pinned } = body;

    // Basic validation
    if (!title || !slug || !content) {
      return NextResponse.json({ error: 'Title, Slug, and Content are required' }, { status: 400 });
    }

    const stmt = db.prepare(`
            INSERT INTO articles (title, slug, content, category, image_url, myvideo_url, is_pinned, excerpt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);

    // Generate excerpt from content (first 100 chars)
    const excerpt = content.replace(/[#*`]/g, '').slice(0, 100) + '...';

    const info = stmt.run(
      title,
      slug,
      content,
      category || '動畫介紹',
      image_url || '/images/default.jpg',
      myvideo_url || '',
      is_pinned ? 1 : 0,
      excerpt
    );

    return NextResponse.json({ id: info.lastInsertRowid, ...body }, { status: 201 });
  } catch (error) {
    console.error('Database Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
