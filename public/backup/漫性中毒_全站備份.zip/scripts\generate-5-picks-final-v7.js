const Database = require('better-sqlite3');
const db = new Database('anime.db');
const https = require('https');
const fs = require('fs');
const path = require('path');

const ASSETS_DIR = path.join(__dirname, '..', 'public', 'assets', 'picks');
if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });

const downloadImage = (url, filename) => {
    return new Promise((resolve) => {
        const filepath = path.join(ASSETS_DIR, filename);
        if (fs.existsSync(filepath)) { resolve(`/assets/picks/${filename}`); return; }
        const file = fs.createWriteStream(filepath);
        https.get(url, (res) => {
            if (res.statusCode !== 200) { resolve(null); return; }
            res.pipe(file);
            file.on('finish', () => { file.close(); resolve(`/assets/picks/${filename}`); });
        }).on('error', () => resolve(null));
    });
};

const BUTTON_HTML = (url) => `<a href="${url}" class="btn-orange-small" target="_blank">前往MyVideo線上觀看</a>`;

async function getAnimeImage(query) {
    try {
        await new Promise(r => setTimeout(r, 600));
        const searchUrl = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=1`;
        return new Promise((resolve) => {
            https.get(searchUrl, (res) => {
                let data = '';
                res.on('data', c => data += c);
                res.on('end', () => {
                    try { resolve(JSON.parse(data).data?.[0]?.images?.jpg?.large_image_url || null); }
                    catch { resolve(null); }
                });
            }).on('error', () => resolve(null));
        });
    } catch { return null; }
}

const contentData = {
    // SPORTS
    '強風吹拂': `「你喜歡跑步嗎？」寬政大學宿舍「竹青莊」的10名雜牌軍，在隊長灰二的帶領下，目標直指日本大學長跑的最高殿堂——箱根驛傳。這部作品最動人之處，在於它描寫一群普通人如何面對自己的極限。從不想跑到不得不跑，再到為了箱根這座山而跑，每一個角色的成長都讓人動容。`,
    '足球風雲！Goal to the Future': `傳奇隊長神谷篤司與對足球感到迷惘的現代高中生辻秀人相遇，開啟了世代的傳承。動畫延續了經典的世界觀，在現代足球風格中找回當年那份純粹的熱血，是寫給過去與未來足球迷的情書。`,
    '網球王子': `從外旋發球到無我境界，這群國中生的網球早已超越了人類的範疇。雖然設定誇張，但它創造了獨一無二的觀影樂趣，角色塑造極為成功，無論是青學九人還是各校強敵，都極具魅力。`,
    '競速OVERTAKE!': `以 F4 賽車為背景，描述落魄攝影師與執著賽車少年之間的羈絆。作品細膩地呈現了賽車運動背後的經濟壓力與技術細節，展現了在極速世界中尋找人生意義的過程。`,
    '蜻蛉高球': `在鹿兒島離島長大的女孩蜻蛉，用一支殘破的鐵桿練就出本能般的球技。當「野性」的高爾夫遇上「科班」的嚴謹，激盪出清新的火花，讓人感受到重回運動本質的快樂。`,
    '白領羽球部': `聚焦在社會人運動員的現實生活。主角白鳥尊在飲料公司羽球部重新找回自我。他們白天是跑業務的社畜，晚上是揮灑汗水的球員，這種工作與夢想的平衡讓成年觀眾深有共鳴。`,
    'SK8 the Infinity': `熱愛滑板的高中生與留學少年，在封閉的礦山中進行名為「S」的極限滑板競賽。流暢的動作設計與鮮艷的角色風格，展現了滑板運動的自由與激情，帶你進入繽紛的次文化領域。`,
    '攀岩少女！': `原本沉迷於益智遊戲的天才少女笠原好，在高中發現了「運動攀登」的樂趣。她將遊戲中的計算與推理運用到攀岩牆上，與隊友們一起挑戰各校強敵，展現了力與美的完美結合。`,
    '群青的開幕曲': `以賽馬學校為背景，講述前偶像少年、少年馬術高手等不同背景的少年，為了成為職業騎師而共同努力。作品捕捉了騎師與賽馬之間細膩的情感，以及在風中疾馳的快感。`,
    '體操武士': `曾經是日本體操界王牌的荒垣城太郎，被教練要求引退後，卻在女兒與神秘密忍者的支持下，決定再次挑戰巔峰。這是一部關於「重啟人生」與「家人羈絆」的溫暖運動動畫。`,

    // ISEKAI
    '無職英雄：技能什麼的毫無用處': `在這個技能決定命運的世界，主角被判定為無效技能的「無職」，卻憑藉著驚人的努力與智慧，開發出了超越系統限制的實力。這是一部打破宿命論，證明努力可以戰勝天賦的勵志作。`,
    '轉生賢者的異世界生活～取得第二職業，成為世界最強～': `原本是社畜的主角轉生後，不知不覺中馴服了一大群史萊姆，並獲得了賢者的力量。他一邊淡定地解決各種危機，一邊過著悠閒的生活，Q彈的史萊姆軍團是本作最大的療癒。`,
    '轉生貴族的異世界冒險錄～不知自重的眾神使徒～': `主角凱因轉生為貴族，卻因為眾神的祝福太過強大而獲得了破格的屬性。他想隱藏實力卻總是不自覺地做出驚人舉動，這種「無自覺強大」帶來的爆笑日常非常舒壓。`,
    '為美好的世界獻上爆焰！': `《為美好的世界獻上祝福！》的前傳，聚焦在惠惠還在紅魔之里的學生時代。看著這位中二少女如何堅持自己的執著，迷戀上那發燒經費的「爆裂魔法」，是粉絲必看的起源故事。`,
    '名湯「異世界溫泉」開拓記~30多歲溫泉狂熱者，轉生到悠閒的溫泉天國~(有修版)': `當溫泉狂熱者來到異世界，他的目標不是打倒魔王，而是開拓溫泉鄉！不管是精靈還是魔物，泡在熱水裡都是跨種族的共通語言，溫暖身心的異世界慢活劇。`,
    '異世界悠閒農家': `轉生到異世界的主角，在深山森林中開荒拓土，看著一片荒地慢慢變成繁榮村莊。這是一個充滿泥土芬芳與收穫喜悅的故事，沒有勾心鬥角，只有大家一起努力生活的溫馨氛圍。`,
    '異世界藥局': `藥學博士轉生後，發現這裡的醫療落後且昂貴。他運用現代知識與物質創造能力，開設平民也看得起病的藥局。這是一部用專業知識治癒世界的職人劇，充滿知性與溫暖。`,
    '異世界迷宮裡的後宮生活': `雖然有著引人遐思的標題，但實際上是對異世界數值、裝備與戰鬥邏輯極為嚴謹的硬核攻略作品。主角步步為營的生存方式，展現了在異世界生活的真實感與策略性。`,
    '異世界自殺突擊隊': `DC 經典反派們穿越到劍與魔法的世界！小丑女哈莉·奎茵與死射等人在異世界大鬧一場。東西方文化與畫風的衝突碰撞，帶來了視覺與爽感兼具的爆米花饗宴。`,
    '骸骨騎士大人異世界冒險中': `玩遊戲玩到一半發現自己穿到了異世界，而且還變成了全身鎧甲的骸骨騎士？主角亞克雖然外表嚇人，卻是一個路見不平拔刀相助的溫柔強者，在旅途中探尋世界的真相。`,

    // HEALING
    '明日同學的水手服': `私立蠟梅學園的清新空氣，與少女們穿上水手服的純粹喜悅。細膩的作畫捕捉了指尖與髮絲的靈動感，這是一部關於青春、友情與生活中那些瑣碎而精緻的小確幸的治癒神作。`,
    '能幹貓今天也憂鬱': `生活廢柴粉領族與超級能幹的巨大黑貓。貓咪諭吉會做飯、打掃、還會管工作，那種「被貓養」的夢幻日常，是所有疲憊上班族最渴望的精神寄託，療癒效果滿分。`,
    '冰屬性男子與無表情女子': `在現代辦公室中，兩位擁有特殊體質（冰雪後裔與無表情）的同事如何漸漸靠近。溫暖的微糖戀愛與柔和的角色互動，像是一杯熱可可，能緩慢融化你心中的焦慮。`,
    '江戶前精靈': `住在神社裡的精靈大人，平日裡是個熱愛網購與遊戲的廢人，卻與年輕巫女小糸建立了深厚的情感。結合了江戶傳統與現代阿宅元素，營造出一種悠閒、溫暖且充滿人情味的氣氛。`,
    '新 我們這一家': `花媽一家的搞笑日常，精準捕捉了普通家庭的碎瑣與溫馨。無論是晚餐吃什麼還是冷氣壞了怎麼辦，這些平凡的小事拼湊出了名為「家」的幸福感，是每個人都能產生共鳴的清爽之作。`,
    '雙人單身露營': `孤高的大叔與菜鳥女大生，展開了「在同一個營地但各露各的」奇妙關係。專業的露營知識配上大人式的交流，展現了在自然中獨處與共處的樂趣，非常適合放鬆心靈。`,
    '房間露營': `撫子等人的社辦日常，發揮想像力在室內進行各種有趣的「模擬露營」。雖然篇幅短小，但依然保留了那種輕鬆愜意、想讓人立刻出發去旅行的高濃度能量。`,
    '比宇宙更遠的地方': `四個少女挑戰去南極。這是一部關於勇氣、夢想與跨出舒適圈的勵志故事。當她們在南極冰原奔跑的那一刻，那份直擊靈魂的純粹與熱情，會讓你也想重新拾起年輕時的夢想。`,
    '休假的壞人先生': `在秘密組織中企圖消滅人類的將軍，到了休假日卻只想著去動物園看貓熊。這種反差極大的「惡役日常」，展現了一種與世無爭的溫和生活態度，看完後心靈會變得很開闊。`,
    '和雨．和你': `一名少林與一隻自稱為「狗」的狸貓。在潮濕的雨天中，她們的相遇開啟了安靜卻溫馨的同居生活。作品風格極其簡約，卻飽含深情，是一部能讓你靜下心來細細品味的珠玉短篇。`,

    // SUSPENSE
    '偵探已經，死了。': `名偵探已死，助手君塚君彥必須帶著她的遺志在殘酷的世界活下去。這是一部充滿謎團與奇幻色彩的偵探冒險，希耶絲塔的魅力與遺留下的佈局，讓故事在死後才真正開始。`,
    '朋友遊戲': `為了還債而參加的神秘遊戲。在金錢面前，原本深厚的友情能否經得起考驗？看著外表無害的主角片切友一如何用瘋狂的邏輯玩弄人性，是一場令人不寒而慄的心理博弈。`,
    '《咒術迴戰 死滅迴游 前篇》': `在宿儺與羂索的陰謀下，日本各地陷入了殘酷的「死滅迴游」。各路強豪為了自身的目標進行生死鬥。MAPPA 頂尖的製作水準展現了領域展開的極致壓迫感，戰局極其緊迫。`,
    '怪物事變': `生活在人類社會陰影下的「怪物」少年們。夏羽在事務所中解決各種詭異事件，同時學習如何擁有「情感」。作品在現代妖怪題材中探討了被疏離者的羈絆，既有戰鬥張力也有人性溫度。`,
    '藥師少女的獨語': `對毒藥有異常執著的貓貓，在後宮中利用藥理知識解開一個個神秘謎團。這不只是破案，更是展示了知識在權力中心如何生存。悠木碧的配音與貓貓的毒藥狂眼神是本作靈魂。`,
    '夏日重現': `網代慎平在故鄉的小島上發現了死亡回歸的能力，並與擁有力量的「影子」進行局勢博弈。島上的夏日風光與陰森殺戮形成強烈對比，劇情節奏極快，環環相扣，結局非常完美。`,
    '屍體如山的死亡遊戲': `異世界的死靈法師穿梭而來，轉生到了現代新宿的一名少年身上。原本以為是懸疑劇，卻演變成了多方勢力交織的都市怪談，充滿了奇妙的幽默感與層層反轉。`,
    '天久鷹央的推理病歷表': `在天醫會綜合醫院內，天才女醫師天久鷹央利用她的超群智力與醫學知識，破解各種被視為不可思議的現象。這是一部結合了醫學與本格推理的另類偵探劇。`,
    '大江戶烈火殺手 - 鳳凰傳說': `在大江戶這個光怪陸離的世界，烈火殺手們在執行任務的過程中發現了背後的巨大陰謀。這是一部風格強烈、充滿時代劇美學與超現實設定的懸疑大作。`,
    '實況主的逃脫遊戲【直播中】': `八位知名的遊戲實況主被綁架到荒島，必須進行實況挑戰來獲得點閱率才能生存。當娛樂變成了生死博弈，實況主們的過去與秘密也被一層層揭開。`,

    // COMEDY
    '孤獨搖滾！': `患有嚴重社恐的波奇醬，夢想透過玩搖滾變得受歡迎。動畫組用各種天馬行空、甚至是崩壞的表現形式完美還原了社恐者的腦內小劇場，首首動聽的歌曲更讓本作成為了經典。`,
    '輝夜姬想讓人告白？特別篇「邁向大人的階梯」': `兩個天才在學生會中進行「逼對方告白」的頭腦戰。明明相愛卻因為過度的自尊而引發無數荒謬的誤解。特別篇更展現了角色們成長的一面，是搞笑與純情並存的高水準喜劇。`,
    '銀魂 3年Z班銀八老師': `無節操與無下限的校園喜劇！銀八老師用他那獨特的慵懶與犀利吐槽，帶領著一班怪咖學生。無論是惡搞其他動畫還是諷刺時事，銀魂的幽默永遠能讓你笑到缺氧。`,
    '鹿乃子乃子乃子虎視眈眈': `這是一部拋棄了邏輯與智商的「鹿」動畫。轉學生鹿乃子那各種違背常理的行為，以及虎視虎子那精采的吐槽，構築了一個完全混沌的搞笑世界。不用理解它，感受它就對了。`,
    '蠟筆小新 海外版': `野原新之助這個5歲小孩，用最荒謬的行為諷刺了大人世界的虛偽與無奈。無論過多久看，小新的屁股外星人與美冴的每日咆哮，依然是解壓的神器。`,
    '天地創造設計部': `神懶得自己創造動物，於是委託設計部代勞。設計師們為了滿足客戶的奇葩需求，在試錯中創造了各種地球上的現實生物。科普與職場笑料的完美結合，非常有創意。`,
    '月刊少女野崎同學': `少女漫畫家身分的壯漢高中生野崎，與暗戀他的佐倉千代。本作對少女漫畫套路的解構與角色們那鋼鐵般的直男邏輯，製造了無數令人噴飯的橋段。`,
    '派對咖孔明': `丞相穿越到現代澀谷當軍師！孔明運用古人的智慧為英子的歌手夢鋪路。兵法與現代演藝圈的結合意外地合拍，配上洗腦的主題曲，節奏明快且超級好笑。`,
    '烏龍派出所特別篇': `淺草的傳奇警官兩津勘吉，只要有錢賺什麼都敢做。他那超群的體力與天馬行空的商業點子，雖然最後都會賠光，但過程中的荒謬絕對能讓你開懷大笑。`,
    '搞笑漫畫日和 +': `短篇冷笑話的巔峰之作。快速的語速、充滿電波的台詞與極致簡潔的畫風，每一集都能精準擊中你的笑穴。這是一場對於常識的徹底顛覆。`
};

const articles = [
    {
        title: '【編輯精選】完全燃燒！10部熱血運動番推薦',
        slug: 'sports-picks-top10-v7',
        category: '編輯精選',
        items: [
            { t: '強風吹拂', id: '17384', q: 'Run with the Wind' },
            { t: '足球風雲！Goal to the Future', id: '20786', q: 'Shoot! Goal to the Future' },
            { t: '網球王子', id: '31153', q: 'Prince of Tennis' },
            { t: '競速OVERTAKE!', id: '25436', q: 'Overtake!' },
            { t: '蜻蛉高球', id: '27046', q: 'Oi! Tonbo' },
            { t: '白領羽球部', id: '19321', q: 'Rymans Club' },
            { t: 'SK8 the Infinity', id: '14691', q: 'SK8 the Infinity' },
            { t: '攀岩少女！', id: '13622', q: 'Iwa Kakeru!' },
            { t: '群青的開幕曲', id: '19987', q: 'Fanfare of Adolescence' },
            { t: '體操武士', id: '13702', q: 'Taiso Samurai' }
        ]
    },
    {
        title: '【編輯精選】異世界轉生看膩了？這10部絕對讓你耳目一新',
        slug: 'isekai-picks-unique-10-v7',
        category: '編輯精選',
        items: [
            { t: '無職英雄：技能什麼的毫無用處', id: '31683', q: 'Mushoku no Eiyuu' },
            { t: '轉生賢者的異世界生活～取得第二職業，成為世界最強～', id: '21049', q: 'My Isekai Life' },
            { t: '轉生貴族的異世界冒險錄～不知自重的眾神使徒～', id: '23245', q: 'Chronicles of an Aristocrat' },
            { t: '為美好的世界獻上爆焰！', id: '23246', q: 'Konosuba Explosion' },
            { t: '名湯「異世界溫泉」開拓記~30多歲溫泉狂熱者，轉生到悠閒的溫泉天國~(有修版)', id: '26203', q: 'Isekai Onsen' },
            { t: '異世界悠閒農家', id: '22427', q: 'Farming Life in Another World' },
            { t: '異世界藥局', id: '20885', q: 'Parallel World Pharmacy' },
            { t: '異世界迷宮裡的後宮生活', id: '21011', q: 'Harem in Labyrinth' },
            { t: '異世界自殺突擊隊', id: '27855', q: 'Suicide Squad Isekai' },
            { t: '骸骨騎士大人異世界冒險中', id: '19790', q: 'Skeleton Knight in Another World' }
        ]
    },
    {
        title: '【編輯精選】生活太累？10部治癒系動畫幫你充電',
        slug: 'healing-picks-relax-10-v7',
        category: '編輯精選',
        items: [
            { t: '明日同學的水手服', id: '18962', q: 'Akebi\'s Sailor Uniform' },
            { t: '能幹貓今天也憂鬱', id: '24156', q: 'The Masterful Cat Is Depressed Again Today' },
            { t: '冰屬性男子與無表情女子', id: '22526', q: 'The Ice Guy and His Cool Female Colleague' },
            { t: '江戶前精靈', id: '23334', q: 'Edomae Elf' },
            { t: '新 我們這一家', id: '2578', q: 'Atashin\'chi' },
            { t: '雙人單身露營', id: '31281', q: 'Futari Solo Camp' },
            { t: '房間露營', id: '12703', q: 'Room Camp' },
            { t: '比宇宙更遠的地方', id: '12704', q: 'A Place Further Than The Universe' },
            { t: '休假的壞人先生', id: '26166', q: 'Mr. Villain\'s Day Off' },
            { t: '和雨．和你', id: '31150', q: 'Ame to Kimi to' }
        ]
    },
    {
        title: '【編輯精選】燒腦神作！10部讓你停不下來的懸疑動畫',
        slug: 'suspense-picks-thriller-10-v7',
        category: '編輯精選',
        items: [
            { t: '偵探已經，死了。', id: '16763', q: 'The Detective Is Already Dead' },
            { t: '朋友遊戲', id: '31432', q: 'Tomodachi Game' },
            { t: '《咒術迴戰 死滅迴游 前篇》', id: '32428', q: 'Jujutsu Kaisen' },
            { t: '怪物事變', id: '14624', q: 'Kemono Jihen' },
            { t: '藥師少女的獨語', id: '24292', q: 'The Apothecary Diaries' },
            { t: '夏日重現', id: '17849', q: 'Summer Time Rendering' },
            { t: '屍體如山的死亡遊戲', id: '23280', q: 'Dead Mount Death Play' },
            { t: '天久鷹央的推理病歷表', id: '29534', q: 'Ameku Takao no Suiri Karte' },
            { t: '大江戶烈火殺手 - 鳳凰傳說', id: '32425', q: 'Ooedo Fireman' },
            { t: '實況主的逃脫遊戲【直播中】', id: '6556', q: 'Naka no Hito Genome' }
        ]
    },
    {
        title: '【編輯精選】笑出腹肌！10部紓壓必看的搞笑動畫',
        slug: 'comedy-picks-lol-10-v7',
        category: '編輯精選',
        items: [
            { t: '孤獨搖滾！', id: '21772', q: 'Bocchi the Rock' },
            { t: '輝夜姬想讓人告白？特別篇「邁向大人的階梯」', id: '32347', q: 'Kaguya-sama' },
            { t: '銀魂 3年Z班銀八老師', id: '31733', q: 'Gintama' },
            { t: '鹿乃子乃子乃子虎視眈眈', id: '27905', q: 'Nokotan' },
            { t: '蠟筆小新 海外版', id: '5364', q: 'Crayon Shin-chan' },
            { t: '天地創造設計部', id: '14619', q: 'Heaven\'s Design Team' },
            { t: '月刊少女野崎同學', id: '5310', q: 'Nozaki-kun' },
            { t: '派對咖孔明', id: '21246', q: 'Kongming' },
            { t: '烏龍派出所特別篇', id: '24692', q: 'Kochikame' },
            { t: '搞笑漫畫日和 +', id: '30833', q: 'Panda-Z' }
        ]
    }
];

(async () => {
    try {
        console.log('🚀 FINAL CONTENT RECOVERY V7 STARTING...');
        const deleteStmt = db.prepare("DELETE FROM articles WHERE slug = ?");
        const insertStmt = db.prepare(`REPLACE INTO articles (title, content, category, slug, published_at, is_pinned, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`);

        for (const article of articles) {
            console.log(`Processing: ${article.title}`);
            deleteStmt.run(article.slug);
            let markdown = '';
            let firstImage = '';
            for (const [index, item] of article.items.entries()) {
                const url = `https://www.myvideo.net.tw/details/3/${item.id}`;
                console.log(`  > ${item.t} -> ${url}`);
                const imageUrl = await getAnimeImage(item.q);
                let localImage = '';
                if (imageUrl) localImage = await downloadImage(imageUrl, `v7_pick_${article.slug}_${index + 1}.jpg`);
                if (index === 0 && localImage) firstImage = localImage;

                markdown += `## ${index + 1}. ${item.t}\n\n`;
                // DO NOT add first image to markdown if it is the same as cover image, 
                // but since the detail page doesn't show cover for pinned articles, we SHOULD add it.
                // However, the editor preview issue was because it showed both. 
                // By making editor preview NOT show cover image for pinned articles, we can add it here safely.
                if (localImage) markdown += `![${item.t}](${localImage})\n\n`;

                const fullText = contentData[item.t];
                if (!fullText) {
                    console.error(`❌ MISSING CONTENT FOR: ${item.t}`);
                    markdown += '（內容恢復中...）\n\n';
                } else {
                    markdown += `${fullText}\n\n`;
                }

                markdown += `${BUTTON_HTML(url)}\n\n---\n\n`;
            }
            const today = new Date().toISOString().split('T')[0];
            insertStmt.run(article.title, markdown, article.category, article.slug, today, 1, firstImage || '/assets/placeholder.jpg');
        }
        console.log('✅ RECOVERY COMPLETE. 50 VERIFIED ITEMS RESTORED.');
    } catch (e) {
        console.error(e);
    }
})();
