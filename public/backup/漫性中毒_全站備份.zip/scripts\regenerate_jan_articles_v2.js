const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'anime.db');
const db = new Database(dbPath);

console.log('📝 Regenerating January Articles (v2) - Long Content & Images...');

// 1. Extract Images
const htmlPath = 'C:/Users/admin/Desktop/anime.html';
const htmlContent = fs.readFileSync(htmlPath, 'utf8');
const imageMap = {};
const regex = /<h2 class="item-title">(.*?)<\/h2>[\s\S]*?<img src="([^"]+)"/g;
let match;
while ((match = regex.exec(htmlContent)) !== null) {
    let title = match[1].replace(/《|》/g, '').split('：')[0].split(' ')[0];
    let img = match[2];
    imageMap[title] = img;
    // Normalized
    if (title.includes('咒術')) imageMap['咒術迴戰'] = img;
    if (title.includes('芙莉蓮')) imageMap['葬送的芙莉蓮'] = img;
    if (title.includes('我推')) imageMap['我推的孩子'] = img;
    if (title.includes('燃油車')) imageMap['燃油車鬥魂'] = img;
    if (title.includes('判處')) imageMap['判處勇者刑'] = img;
    if (title.includes('相反')) imageMap['相反的你和我'] = img;
    if (title.includes('公主')) imageMap['公主殿下'] = img;
    // Map missing ones manually if needed (Fate, Party, Kaguya might not be in the HTML 10 items? User HTML had 10 items?
    // Let's check `items` array from previous script vs HTML.
    // HTML had: Vigilantes, Sentenced, JJK, Fire Force, Opposites, Fire Eater, Torture, Oshi no Ko, MF Ghost, Frieren.
    // User requested: Frieren, Oshi no Ko, JJK, MF Ghost, Party, Sentenced, Kaguya, Fate, Opposites, Torture.
    // HTML has: Vigilantes, Fire Force, Fire Eater.
    // Missing in HTML: Party, Kaguya, Fate.
    // We need placeholders for these 3 if not in HTML.
    // Use generic placeholders or best guess.
}

// Fallback images
const fallbackImg = '/assets/placeholder.jpg';
const getImg = (key) => imageMap[key] || fallbackImg;

// 2. Define Long Content (approx 300 chars)
// I will create rich descriptions.
const items = [
    {
        t: '葬送的芙莉蓮 第二季',
        key: '葬送的芙莉蓮',
        url: 'https://www.myvideo.net.tw/details/4/32568',
        desc: '這是一部關於「結束之後」的故事。打倒魔王、凱旋歸來的勇者一行人，在慶祝之後回歸了各自的生活。對於擁有千年壽命的精靈魔法使芙莉蓮來說，這十年的冒險僅僅是生命中的一瞬，但對人類夥伴而言，卻是一生的羈絆。在送別了勇者欣梅爾後，芙莉蓮深刻體會到人類生命的短暫與脆弱，為了更了解「人類」，她踏上了前往從前冒險之地的旅程。\n在第二季中，芙莉蓮通過了一級魔法使考試，與弟子費倫、戰士修塔爾克繼續向北部高原前進，目標是傳說中靈魂長眠之地——歐雷全。在那裡，她希望能再次見到欣梅爾，並解開關於當年冒險中未曾提及的秘密。本季將有更多關於魔法世界的深度描寫，以及與魔族「七崩賢」殘黨的激烈戰鬥。Madhouse 的製作水準依舊維持頂尖，細膩的作畫與悠揚的配樂，將帶給觀眾最沉浸的奇幻體驗。這不僅是戰鬥番，更是一部探討時間、記憶與傳承的感人詩篇。'
    },
    {
        t: '我推的孩子 第二季',
        key: '我推的孩子',
        url: 'https://www.myvideo.net.tw/details/3/23277',
        desc: '演藝圈的光鮮亮麗之下，隱藏著無數的謊言與黑暗。繼第一季震撼全球的開場與「B小町」的重生後，第二季將進入原作中最受好評的「舞台劇篇」。阿奎亞為了追查殺害母親星野愛的真兇，決定參與「劇團Lalalai」的2.5次元舞台劇演出。在這裡，他將遭遇演技天才黑川茜與兒時玩伴有馬佳奈的激烈競爭，三人之間的演技碰撞與情感糾葛將成為本季最大看點。\n另一方面，露比也在偶像這條充滿荊棘的道路上持續努力，試圖追趕母親的背影。本季將更深入探討演藝圈的殘酷現實，包括原作者與改編劇本的角力、童星的轉型困境、以及為了成名必須付出的代價。動畫工房一貫的高品質製作，搭配張力十足的劇情與神級片尾曲，絕對是本季話題霸權。看著阿奎亞如何在復仇與夢想之間掙扎，以及那些為了「謊言」而活著的人們，將如何演繹出最真實的自己。'
    },
    {
        t: '咒術迴戰 死滅迴游 前篇',
        key: '咒術迴戰',
        url: 'https://www.myvideo.net.tw/details/4/24125',
        desc: '澀谷事變帶來的破壞與絕望尚未平息，更殘酷的生存遊戲「死滅迴游」已然展開。這是由史上最惡咒術師加茂憲倫（羂索）所策劃，為了讓全日本人類與天元同化，進而強迫所有咒術師與非術師參與的互相殘殺儀式。主角虎杖悠仁為了贖罪、為了拯救姐姐津美紀，以及解開封印五條悟的「獄門疆」，毅然決然地投身這場地獄般的遊戲。\n本篇章將聚焦於規則複雜且充滿智鬥的戰鬥過程，除了主角群外，許多過去未曾展現實力的特級術師如乙骨憂太，以及新登場的強者如同賭徒般的秤金次、戰鬥狂鹿紫雲一都將大顯身手。MAPPA 再次展現了劇場版等級的動作場面，流暢的運鏡與充滿迫力的咒術對決，保證讓熱血漫迷大呼過癮。這不僅是單純的力量比拚，更是信念與覺悟的碰撞。在沒有五條悟的世界裡，他們該如何守護最後的光明？'
    },
    {
        t: '燃油車鬥魂 第三季',
        key: '燃油車鬥魂',
        url: 'https://www.myvideo.net.tw/details/4/28879',
        desc: '在電動車普及、內燃機車輛即將絕跡的未來，這是一首獻給汽油引擎的最後輓歌。「MFG」這項在日本舉行的公道賽車運動，以其不限改裝、追求極速的野生魅力席捲全球。繼承了「秋名山車神」藤原拓海意志的天才車手片桐夏向，駕駛著相對於對手超跑而言性能劣勢的 Toyota 86，憑藉著神乎其技的駕駛技術，在強敵環伺的賽場上屢創奇蹟。\n第三季故事來到 MFG 年度賽事的關鍵第三戰「The Peninsula 真鶴」。這條賽道結合了高速直線與蜿蜒山路，對車手的綜合實力是極大考驗。夏向將面臨來自「神之十五人」中更強大的對手，包括擁有壓倒性馬力的法拉利、藍寶堅尼等頂級超跑。引擎的咆哮聲、輪胎的摩擦聲、以及那熟悉的歐陸節拍（Eurobeat），將再次點燃觀眾心中的賽車魂。這是一部關於速度、傳承與夢想的熱血作品，絕對不容錯過。'
    },
    {
        t: '泛而不精的我被逐出了勇者隊伍',
        key: '泛而不精', // Missing in HTML
        url: 'https://www.myvideo.net.tw/details/3/32390',
        desc: '這是一個關於「承認自我價值」的溫馨故事。主角奧恩因為本身能力數值平均，被認為樣樣通樣樣鬆，而被勢利的勇者隊伍視為累贅無情踢除。然而，他們卻不知道奧恩其實一直在背後默默使用各種輔助魔法與道具，支撐著整個隊伍的運作。離開隊伍的奧恩並沒有因此喪志，反而決定在邊境小鎮開始悠閒的慢生活。\n在新的生活中，他運用那些被前隊友輕視的「泛而不精」技能，解決了許多連專職冒險者都束手無策的難題，意外地成為了小鎮的守護神，並邂逅了許多珍貴的夥伴。本作打破了傳統對於「強者」的定義，強調實用性與智慧的重要性。看著主角如何用看似平凡的能力打臉前隊友，並在輕鬆的日常中收穫真摯的友情與愛情，是一部節奏舒適、看完會讓人心情愉快的異世界漫遊系作品。'
    },
    {
        t: '判處勇者刑',
        key: '判處勇者刑',
        url: 'https://www.myvideo.net.tw/details/3/32447',
        desc: '「勇者」這個稱號，如果變成了一種最殘酷的「刑罰」？這部改編自話題輕小說的暗黑奇幻大作，徹底顛覆了我們對勇者故事的想像。主角扎伊羅曾經是拯救世界的英雄，卻因為犯下大罪而被剝奪了一切，被判處名為「勇者之刑」的極刑——那就是必須永遠以勇者的身分戰鬥，直到死亡為止，甚至連死後都不得安寧。\n為了對抗捲土重來的魔王軍，王國集結了一群由極惡罪犯組成的「懲罰勇者部隊」。這裡沒有光鮮亮麗的正義，只有為了生存與減刑而進行的血腥殺戮。扎伊羅必須率領這群人渣隊友，在絕望的戰場上尋找一絲救贖。本作以厚重的筆觸描繪了人性的醜惡與光輝，戰鬥描寫拳拳到肉，劇情充滿道德的灰色地帶與反轉。如果你看膩了樣板化的異世界番，這部充滿血腥味與沈重感的作品絕對能帶來強烈的衝擊。'
    },
    {
        t: '輝夜姬想讓人告白？特別篇「邁向大人的階梯」',
        key: '輝夜姬', // Missing in HTML
        url: 'https://www.myvideo.net.tw/details/3/32347',
        desc: '天才們的戀愛頭腦戰，這次將邁出關鍵的一大步！秀知院學園的學生會長白銀御行與副會長四宮輝夜，在經歷了無數次的試探與攻防後，兩人的關係終於在奉心祭後有了決定性的進展。本次特別篇「邁向大人的階梯」將聚焦於兩人在確立心意後，如何面對即將到來的「第一次」。\n這不僅僅是戀愛的甜蜜，更包含了青春期對於親密關係的懵懂、期待與不安。原作中赤坂明老師以其獨特的幽默感與細膩的心理描寫，將這段略顯青澀卻又無比真實的過程刻畫得淋漓盡致。動畫版將延續一貫的高水準演出，搭配聲優古賀葵與古川慎的精湛配音，保證讓觀眾在捧腹大笑的同時，也被兩人的純情閃瞎雙眼。這是一部獻給所有曾經歷或嚮往青春戀愛的人們的禮物，也是輝夜姬系列邁向完結的重要篇章。'
    },
    {
        t: 'Fate/strange Fake',
        key: 'Fate', // Missing in HTML
        url: 'https://www.myvideo.net.tw/details/3/29508',
        desc: '這是發生在美國西部雪原市，一場充滿謎團與異常的「虛偽聖杯戰爭」。不同於冬木市的正規戰爭，這場由不知名魔術師所策劃的儀式，從一開始就充滿了扭曲：原本應該有的七個職階變成了十三個，甚至出現了不該存在的從者。各方勢力為了各自的目的集結於此，展開了一場沒有規則的混戰。\n本作由《無頭騎士異聞錄》作者成田良悟執筆，將原本龐大的 Fate 世界觀再次擴張。讀者將看到許多傳說中的英靈以意想不到的形式登場，例如身為「毀滅」化身的恩奇都、身為「瘟疫」概念的蒼白騎士，以及本次聖杯戰爭最核心的謎團——吉爾伽美什的現身。劇情錯綜複雜，多線敘事交織出宏大的群像劇。動畫由 A-1 Pictures 傾力製作，華麗的特效與壯闊的場景，將這場「神仙打架」的史詩感完美呈現。'
    },
    {
        t: '相反的你和我',
        key: '相反的你和我',
        url: 'https://www.myvideo.net.tw/details/3/32423',
        desc: '在這個稍稍有些浮躁的時代，我們都需要一點純粹的糖分來治癒心靈。故事講述了充滿活力、總是走在流行尖端的辣妹鈴木，與沈默寡言、總是獨來獨往的眼鏡男谷，這兩個看似處於校園階級兩端、性格完全相反的人，卻意外地擦出了戀愛的火花。\n沒有令人胃痛的誤會，也沒有拖泥帶水的糾葛，這部作品主打的就是「直球對決」的爽快感。鈴木總是毫不掩飾地表達對谷的喜愛，而谷雖然害羞，也會用自己的方式給予回應。兩人之間充滿默契的互動，以及周遭朋友們溫暖的守護，構成了一幅最美好的青春畫卷。作者阿賀澤紅茶以其獨特的線條風格與生動的人物表情，讓這部作品在眾多校園漫中獨樹一幟。無論你是正在戀愛中，還是單身一人，這部充滿正能量與心動瞬間的動畫，絕對能讓你嘴角失守，重拾對愛情的憧憬。'
    },
    {
        t: '公主殿下，「拷問」的時間到了 第二季',
        key: '公主殿下',
        url: 'https://www.myvideo.net.tw/details/3/26411',
        desc: '「屈服吧！在美味與誘惑面前，人類的尊嚴根本不值一提！」史上最廢柴（?）的人質公主與最溫柔的魔王軍拷問官們回來了！身為國王軍團長兼聖劍持有者的公主，在被魔王軍俘虜後，每天都要面對慘無人道的——美食拷問。從剛出爐的吐司、頂級的拉麵，到溫泉旅行與電玩遊戲，魔王軍無所不用其極地想讓公主招供，而公主也總是不負眾望地在三秒內光速投降，洩漏各種無關緊要的王國機密。\n第二季將帶來更多腦洞大開的「刑具」與更爆笑的互動。除了既有的拷問官外，魔王的女兒、甚至是魔王本人都將加入這場鬧劇。這部作品沒有沉重的劇情，只有滿滿的療癒與笑點。看著公主大口吃著美食的幸福模樣，不僅能勾起你的食慾，更能洗滌一整天的疲憊。這絕對是本季最佳的配飯動畫，強烈建議不要在深夜空腹時觀看！'
    }
];

// Helper to Insert
const insertArticle = (title, slug, content, date, isPinned = 0) => {
    // 1. Assign unique image for cover (random logic or specific)
    const coverImg = '/assets/placeholder.jpg'; // We updated this in previous step using assign_unique_images.js check, but here we overwrite content. 
    // We should preserve the image_url if it exists?
    // Actually, I'll just rely on the fallback or previous script. 
    // BUT the SQL REPLACE will overwrite image_url.
    // I should get existing image_url if possible.
    const existing = db.prepare('SELECT image_url FROM articles WHERE slug = ?').get(slug);
    const finalImg = existing ? existing.image_url : coverImg;

    const stmt = db.prepare(`REPLACE INTO articles (title, content, category, slug, published_at, is_pinned, image_url, excerpt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    stmt.run(title, content, '編輯精選', slug, date, isPinned, finalImg, '本週新番更新懶人包！');
    console.log(`✅ Regenerated: ${title}`);
};

// Generate Full Content
const generateBody = (introText, weekPrefix = '') => {
    let body = introText + '\n\n';
    items.forEach((item, idx) => {
        const imgUrl = getImg(item.key) || getImg(item.t.split(' ')[0]);
        // Layout: Centered Image -> Title -> Text -> Button
        // Markdown Image: ![Alt](Url)

        let sectionTitle = item.t;
        if (weekPrefix) sectionTitle += ` (${weekPrefix})`;

        body += `## ${sectionTitle}\n\n`;
        // Check "No Left Float". Default Markdown `![]` is usually block level or inline. 
        // We'll add standard markdown image.
        if (imgUrl) {
            body += `![${item.t}劇照](${imgUrl})\n\n`;
        }

        body += `${item.desc}\n\n`;
        body += `<a href="${item.url}" class="btn-orange-small" target="_blank">前往MyVideo線上觀看</a>\n\n`;
        body += `---\n\n`;
    });
    return body;
};

// 1. Highlight
const highlightBody = generateBody('2026 1月新番開播啦！本季強檔雲集，不知道該追哪部嗎？編輯部精選了 10 部絕對不能錯過的話題大作，從熱血戰鬥到戀愛喜劇應有盡有！');
insertArticle('【1月新番】重點動畫更新總整理！這10部你跟上了嗎？', 'jan-2026-highlights', highlightBody, '2026-01-01');

// 2. Weekly (Vol 1-4)
for (let i = 1; i <= 4; i++) {
    const weekBody = generateBody(`1月新番進入第 ${i} 週，劇情漸入佳境！以下是本週 10 部重點動畫的最新更新情報：`, `EP.${i}`);
    insertArticle(`【1月新番週報】Vol.${i}：本週更新重點速報`, `jan-2026-weekly-vol-${i}`, weekBody, `2026-01-${i * 7}`);
}

console.log('🎉 All articles regenerated with rich content and images.');
