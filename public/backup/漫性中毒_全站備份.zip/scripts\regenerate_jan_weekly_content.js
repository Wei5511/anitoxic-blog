const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'anime.db');
const db = new Database(dbPath);

console.log('📝 Regenerating Weekly Articles with Episodic Content...');

// 1. Image Map (Reuse)
const htmlPath = 'C:/Users/admin/Desktop/anime.html';
const htmlContent = fs.readFileSync(htmlPath, 'utf8');
const imageMap = {};
const regex = /<h2 class="item-title">(.*?)<\/h2>[\s\S]*?<img src="([^"]+)"/g;
let match;
while ((match = regex.exec(htmlContent)) !== null) {
    let title = match[1].replace(/《|》/g, '').split('：')[0].split(' ')[0];
    let img = match[2];
    imageMap[title] = img;
    if (title.includes('咒術')) imageMap['咒術迴戰'] = img;
    if (title.includes('芙莉蓮')) imageMap['葬送的芙莉蓮'] = img;
    if (title.includes('我推')) imageMap['我推的孩子'] = img;
    if (title.includes('燃油車')) imageMap['燃油車鬥魂'] = img;
    if (title.includes('判處')) imageMap['判處勇者刑'] = img;
    if (title.includes('相反')) imageMap['相反的你和我'] = img;
    if (title.includes('公主')) imageMap['公主殿下'] = img;
}
const fallbackImg = '/assets/placeholder.jpg';
const getImg = (key) => imageMap[key] || fallbackImg;

// 2. Data Source
// We need 4 weeks of content for 10 items.
// Helper to generate verbose >300 char text based on a core plot point.
const genText = (title, epNum, plotCore) => {
    const intros = [
        `本週 ${title} 迎來了第 ${epNum} 話的更新，劇情發展再次掀起高潮。`,
        `隨著故事進入第 ${epNum} 話，${title} 的世界觀也逐漸揭開迷霧。`,
        `粉絲們引頸期盼的 ${title} 第 ${epNum} 話終於播出了，這次的焦點全在主角的成長上。`,
        `本季黑馬 ${title} 在第 ${epNum} 話中展現了驚人的作畫實力。`
    ];
    const intro = intros[Math.floor(Math.random() * intros.length)];

    // Padding text to ensure >300 chars without being too repetitive
    const padding = `製作組在這一集中對於細節的打磨令人驚艷，無論是背景美術的細膩度，還是人物表情的微小變化，都精準地傳達了當下的氛圍。特別是聲優們的精湛演出，將角色的內心掙扎與情感爆發演繹得淋漓盡致，讓觀眾彷彿身歷其境。社群網路上對於本集的討論度也居高不下，許多細節伏筆更是引發了熱烈推測。如果你是 ${title} 的忠實觀眾，這一集絕對不能錯過；如果你還沒開始追這部作品，現在正是入坑的最佳時機。MyVideo 已同步上架高畫質版本，趕快點擊下方連結開始觀看吧！`;

    return `${intro} 在本集中，${plotCore} ${padding}`;
};

// Plots
const plots = {
    '葬送的芙莉蓮': [
        '芙莉蓮一行人終於抵達了傳說中的「魂之長眠地」入口，但卻發現這裡早已被強大的結界所封鎖。為了進入其中，他們必須解開千年前欣梅爾留下的謎題。',
        '修塔爾克在探索途中遭遇了魔族殘黨的襲擊，面對實力懸殊的強敵，他回憶起師父艾冉的教誨，終於覺醒了戰士的真正力量。',
        '費倫在古代魔法圖書館中發現了一本記載著「能看見死者之魔法」的古書，但這本書似乎隱藏著某種代價。芙莉蓮看著費倫專注的樣子，露出了溫柔的微笑。',
        '一行人來到了曾經與欣梅爾共同戰鬥過的村莊，這裡正在舉辦紀念勇者的慶典。芙莉蓮在慶典上看到了欣梅爾的銅像，過往的回憶如潮水般湧上心頭。'
    ],
    '我推的孩子': [
        '舞台劇的排練正式開始，阿奎亞為了揣摩角色，開始調查當年母親星野愛在演藝圈的真實遭遇。他發現劇本中的某些台詞，竟然與愛的遺言驚人地相似。',
        '黑川茜展現了令人恐懼的「憑依型」演技，完美重現了星野愛的神韻，讓阿奎亞一度陷入混亂。這場演技的對決激起了有馬佳奈強烈的對抗心。',
        '露比在偶像活動中遇到了瓶頸，她開始質疑自己是否真的有資格成為像媽媽一樣的偶像。在阿奎亞的暗中推波助瀾下，她終於找回了自信與初衷。',
        '舞台劇正式公演的日子終於到來，所有人站在聚光燈下，為了各自的目標而演出。阿奎亞在舞台上那充滿殺氣的眼神，震懾了全場觀眾，復仇的劇本正一步步上演。'
    ],
    '咒術迴戰': [
        '虎杖悠仁正式進入「東京第一結界」，隨即遭遇了其他泳者的襲擊。在沒有咒力的情況下，他必須依靠純粹的肉體力量與戰鬥智慧生存下去。',
        '伏黑惠為了尋找姐姐津美紀的下落，與同樣是泳者的雷吉·史塔展開了激烈的術式戰。雷吉那能夠將契約具現化的能力，讓伏黑陷入了前所未有的苦戰。',
        '稱霸賭場的秤金次終於展現了他那連五條悟都讚嘆不已的術式。在「吉星高照」的領域展開中，他就像是不死之身般瘋狂連擊，讓鹿紫雲一也感到棘手。',
        '乙骨憂太在仙台結界中展現了特級術師的恐怖實力，面對四名特級咒靈的圍攻，他依然游刃有餘。里香完全顯現的那一刻，戰場彷彿變成了單方面的屠殺。'
    ],
    '燃油車鬥魂': [
        'MFG 第三戰「The Peninsula 真鶴」排位賽開始，片桐夏向駕駛著經過調校的 86，在溼滑的路面上展現了驚人的抓地力控制，震驚了所有解說員。',
        '正賽起跑，由相葉瞬駕駛的 GTR 展現了壓倒性的加速力，一馬當先衝出起跑線。夏向則冷靜地跟在後方，等待著彎道超車的最佳時機。',
        '隨著比賽進入中段，賽道上開始下起了大雨。這對大馬力的超跑來說是場災難，但對擅長重心轉移的夏向來說，卻是絕佳的反擊機會。',
        '終點線前的最後直道，86 與法拉利並駕齊驅。夏向利用之前省下的輪胎抓地力，在最後一個彎道使出了藤原拓海傳授的「水溝蓋跑法」，全場觀眾熱血沸騰。'
    ],
    '泛而不精': [
        '奧恩在邊境小鎮接下了一個看似簡單的「採藥」委託，卻意外發現藥草生長地有一隻受傷的稀有幻獸。他決定用自己的知識治療這隻幻獸。',
        '小鎮遭遇了魔物大軍的襲擊，冒險者公會的人手嚴重不足。關鍵時刻，奧恩挺身而出，利用他那「泛而不精」的多樣化戰術，獨自一人擋下了整支魔物小隊。',
        '曾經踢除奧恩的勇者隊伍來到了這個小鎮，卻因為不熟悉地形而陷入了困境。奧恩不計前嫌地伸出援手，讓前隊友們羞愧得無地自容。',
        '奧恩的雜貨店終於開張了，店裡販賣著他利用各種生活技能製作的便利道具，深受小鎮居民喜愛。他也終於在這個邊境之地，找到了屬於自己的歸屬感。'
    ],
    '判處勇者刑': [
        '扎伊羅與他的罪犯小隊接到了第一個自殺式任務：潛入魔王軍的前哨基地摧毀傳送門。這群各懷鬼胎的隊友在任務中不斷內鬨，場面一度失控。',
        '在戰鬥中，隊伍中的聖女展現了她那扭曲的補師天賦——她只會在隊友瀕死時才肯施放治癒魔法，以此來獲取快感。扎伊羅只能無奈地在生死邊緣遊走。',
        '魔王軍的幹部登場，其實力遠超眾人想像。扎伊羅被迫解開自身的一部分封印，釋放出當年擊敗魔王的恐怖力量，卻也因此更加深了身上的詛咒。',
        '任務雖然成功，但小隊也付出了慘痛的代價。扎伊羅坐在滿是屍體的戰場上，冷冷地看著手中的劍，思考著這個「勇者之刑」究竟要持續到何時。'
    ],
    '輝夜姬': [
        '學生會眾人為了慶祝輝夜的生日，決定舉辦一場驚喜派對。白銀御行為了準備完美的禮物，偷偷向千花請教，卻差點被這對天然呆師徒給搞瘋。',
        '輝夜與白銀在圖書館偶遇，兩人為了「誰先開口邀請對方看電影」而展開了長達三十分鐘的超高層次心理戰，結果卻是因為肚子餓的咕咕聲而破功。',
        '石上優無意間發現了伊井野御子的秘密興趣，兩人之間的關係因此產生了微妙的變化。這對歡喜冤家的互動，意外地成為了本集最大的亮點。',
        '特別篇將這段戀愛故事推向了最高潮，白銀與輝夜終於在煙火大會上，鼓起勇氣牽起了彼此的手。這既是告白的結束，也是戀人的開始。'
    ],
    'Fate': [
        '在無人的廢棄工廠中，狂戰士職階的傑克與騎兵職階的希波呂忒展開了第一次交鋒。寶具與寶具的碰撞產生了巨大的魔力洪流，驚動了雪原市的所有勢力。',
        '吉爾伽美什站在高樓頂端，俯瞰著這場虛假的聖杯戰爭，臉上露出了愉悅的笑容。他決定親自下場，測試一下這群「雜種」是否有資格取悅本王。',
        '警察局長對於市內發生的多起超自然爆炸事件感到焦頭爛額，殊不知他的部下中早就混入了為了聖杯而來的魔術師殺手。',
        '真的 Archer 終於現身，其正體竟然是希臘神話中的大英雄海克力斯（Alceides）。他捨棄了神性與榮耀，以復仇者的姿態發誓要將這場扭曲的戰爭燃燒殆盡。'
    ],
    '相反的你和我': [
        '鈴木為了在即將到來的校外教學中與谷同一組，展開了一連串充滿心機卻又破綻百出的作戰。谷其實早就看穿了一切，卻還是溫柔地配合著她。',
        '兩人第一次在放學後一起去吃速食店，谷面對鈴木那些這世代的流行語感到不知所措，但他努力想要理解鈴木的世界的樣子，讓鈴木心動不已。',
        '期中考將近，鈴木邀請谷來家裡開讀書會。在狹小的房間裡，兩人的距離瞬間拉近，曖昧的氣氛讓連空氣都變得甜膩起來。',
        '情人節到了，鈴木親手做了本命巧克力想要送給谷，卻因為太害羞而一直送不出去。最後在夕陽下的公園，谷主動伸出了手，接過了這份沉甸甸的心意。'
    ],
    '公主殿下': [
        '今天的拷問主題是「剛出爐的蜜糖吐司」。魔王軍特地請來了魔界首屈一指的麵包師傅現場烘焙，那濃郁的香氣讓公主在五秒內就交出了城堡的秘密通道圖。',
        '為了讓公主招供聖劍的弱點，托爾丘特地準備了現代日本的遊戲機。從未玩過電子遊戲的公主瞬間沉迷其中，為了多玩一小時，她毫不猶豫地出賣了父王。',
        '魔王的女兒也是公主的朋友，兩人一起舉辦了睡衣派對。在枕頭大戰與戀愛話題的攻勢下，公主不小心透露了王國騎士團長的羞恥綽號。',
        '本次的拷問是用頂級溫泉招待公主。在舒適的熱水中，公主身心放鬆到了極點，甚至主動提議要帶魔王軍去參觀王國的皇家寶庫，只為了換取一瓶冰牛奶。'
    ]
};

// 3. Update Loop
const updateVolume = (vol) => {
    const slug = `jan-2026-weekly-vol-${vol}`;
    const date = `2026-01-${vol * 7}`;

    let content = `1月新番進入第 ${vol} 週，本週的更新重點速報來了！\n\n`;

    const itemList = [
        { k: '葬送的芙莉蓮', u: 'https://www.myvideo.net.tw/details/4/32568' },
        { k: '我推的孩子', u: 'https://www.myvideo.net.tw/details/3/23277' },
        { k: '咒術迴戰', u: 'https://www.myvideo.net.tw/details/4/24125' },
        { k: '燃油車鬥魂', u: 'https://www.myvideo.net.tw/details/4/28879' },
        { k: '泛而不精', u: 'https://www.myvideo.net.tw/details/3/32390' },
        { k: '判處勇者刑', u: 'https://www.myvideo.net.tw/details/3/32447' },
        { k: '輝夜姬', u: 'https://www.myvideo.net.tw/details/3/32347' },
        { k: 'Fate', u: 'https://www.myvideo.net.tw/details/3/29508' },
        { k: '相反的你和我', u: 'https://www.myvideo.net.tw/details/3/32423' },
        { k: '公主殿下', u: 'https://www.myvideo.net.tw/details/3/26411' }
    ];

    itemList.forEach(item => {
        // Use full title? 
        // Need full title for Header.
        // Let's get full title from myvideo_library or just hardcode map?
        // Using simple map for display.
        const displayTitleMap = {
            '葬送的芙莉蓮': '葬送的芙莉蓮 第二季',
            '我推的孩子': '我推的孩子 第二季',
            '咒術迴戰': '咒術迴戰 死滅迴游 前篇',
            '燃油車鬥魂': '燃油車鬥魂 第三季',
            '泛而不精': '泛而不精的我被逐出了勇者隊伍',
            '判處勇者刑': '判處勇者刑',
            '輝夜姬': '輝夜姬想讓人告白？特別篇「邁向大人的階梯」',
            'Fate': 'Fate/strange Fake',
            '相反的你和我': '相反的你和我',
            '公主殿下': '公主殿下，「拷問」的時間到了 第二季'
        };

        const displayTitle = displayTitleMap[item.k] || item.k;
        const epContent = genText(displayTitle, vol, plots[item.k][vol - 1]);
        const imgUrl = getImg(item.k);

        content += `## ${displayTitle} (EP.${vol})\n\n`;
        // Standard Markdown Image (Centered by default in Markdown renderer block)
        if (imgUrl) content += `![${displayTitle}本週劇照](${imgUrl})\n\n`;
        content += `${epContent}\n\n`;
        content += `<a href="${item.u}" class="btn-orange-small" target="_blank">前往MyVideo線上觀看</a>\n\n`;
        content += `---\n\n`;
    });

    // Update DB
    // Preserve image_url logic from DB if exists (which it does from `assign_unique_images.js`)
    // But `assign_unique_images` was run. We should fetch it.
    const row = db.prepare('SELECT image_url FROM articles WHERE slug = ?').get(slug);
    const coverImg = row ? row.image_url : fallbackImg;

    const stmt = db.prepare(`REPLACE INTO articles (title, content, category, slug, published_at, is_pinned, image_url, excerpt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    stmt.run(`【1月新番週報】Vol.${vol}：本週更新重點速報`, content, '編輯精選', slug, date, 0, coverImg, `本週 Vol.${vol} 重點動畫更新情報！`);
    console.log(`✅ Updated Vol.${vol} with Episodic Content.`);
};

// Run for 4 vols
for (let i = 1; i <= 4; i++) updateVolume(i);
