const Database = require('better-sqlite3');
const db = new Database('anime.db');
const https = require('https');
const fs = require('fs');
const path = require('path');

const ASSETS_DIR = path.join(__dirname, '..', 'public', 'assets', 'picks');
if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });

// Helper to download image
const downloadImage = (url, filename) => {
    return new Promise((resolve, reject) => {
        const filepath = path.join(ASSETS_DIR, filename);
        const file = fs.createWriteStream(filepath);
        https.get(url, (res) => {
            if (res.statusCode !== 200) {
                reject(new Error(`Failed to download: ${res.statusCode}`));
                return;
            }
            res.pipe(file);
            file.on('finish', () => {
                file.close();
                resolve(`/assets/picks/${filename}`);
            });
        }).on('error', (err) => {
            fs.unlink(filepath, () => { });
            reject(err);
        });
    });
};

// STRIC BUTTON HTML for RenderMarkdown.js regex: ^<a href="([^"]+)" class="btn-orange-small" target="_blank">(.+)<\/a>$
// DO NOT ADD rel="noopener noreferrer" or other attributes!
const BUTTON_HTML = (url) => `<a href="${url}" class="btn-orange-small" target="_blank">前往MyVideo線上觀看</a>`;

// Helper to generate 500+ words content
const generateLongContent = (item, theme) => {
    return `
### 作品簡介
**${item.title}** 是近年來在${theme}類型中不可多得的佳作。本作不僅在作畫與音樂上表現出色，更在劇情深度上達到了新的高度。對於看膩了千篇一律套路的觀眾來說，這絕對是一部能讓你找回追番熱情的作品。故事的節奏掌握得恰到好處，從第一集開始就埋下了吸引人的伏筆，隨著劇情的推進，每一個角色的成長與轉變都讓人感同身受。無論是想要尋找熱血的感動，還是想要在繁忙的生活中尋求一絲治癒，這部作品都能滿足你的需求。製作組對於細節的考究令人驚艷，從背景美術到人物的微表情，處處都能看見匠心獨運。這不僅僅是一部動畫，更是一場視覺與聽覺的盛宴。

### 劇情大綱與看點
${item.desc}
故事的核心圍繞著主角如何在困境中突破自我。不同於傳統的主角光環，本作花了很多篇幅描寫角色的挫折與迷惘。正是因為有了這些真實的掙扎，最後的成功才顯得格外耀眼。製作組在名場面上的經費投入毫不手軟，流暢的戰鬥分鏡（或是細膩的日常演繹）搭配上契合度極高的配樂，能瞬間將觀眾的情緒帶入最高潮。此外，配角群的刻畫也相當立體，每一個角色都有自己的行動邏輯與背後故事，共同交織出這個豐富多彩的世界觀。隨著故事發展，你會發現原本看似無關的細節，最後都串連成了一個龐大的伏筆，這種恍然大悟的快感是觀看本作的一大樂趣。

### 為何推薦
為什麼這部作品值得你花時間觀看？因為它探討了人性的光輝與脆弱。在${theme}的外皮下，它其實講述的是關於「連結」與「希望」的故事。不管是角色之間的羈絆，還是即使面對絕望也不放棄的勇氣，都能給螢幕前的我們帶來力量。這是一部適合靜下心來細細品味的動畫，每一遍觀看都能發現新的細節與感動。如果你正在尋找一部能夠列入「人生必看」清單的作品，那麼請絕對不要錯過。它不會刻意說教，而是透過角色的經歷讓你自然而然地思考許多深刻的議題。

### 編輯總結
總結來說，**${item.title}** 是一部集結了優秀劇本、頂級製作與深刻內涵的全方位神作。它完美的詮釋了${theme}類型的精髓，同時又做出了大膽的創新。強烈推薦給所有喜愛日本動畫的朋友。現在就點擊下方的連結，前往 MyVideo 開始這趟精彩的旅程吧！相信在看完第一集之後，你就會停不下來，迫不及待想知道後續的發展。
    `.trim();
};

// Jikan Search helper
async function getAnimeImage(query) {
    try {
        console.log(`  Searching Jikan for: ${query}`);
        await new Promise(r => setTimeout(r, 1200));
        const searchUrl = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=1`;

        return new Promise((resolve, reject) => {
            https.get(searchUrl, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        if (json.data && json.data.length > 0) {
                            resolve(json.data[0].images.jpg.large_image_url);
                        } else {
                            resolve(null);
                        }
                    } catch (e) {
                        resolve(null);
                    }
                });
            }).on('error', (e) => resolve(null));
        });
    } catch (e) {
        return null;
    }
}

const articles = [
    {
        title: '【編輯精選】5部其實是10部！完全燃燒的熱血運動番推薦',
        slug: 'sports-picks-top10',
        intro: '運動番的魅力不只是輸贏，而是那份為了目標燃燒殆盡的熱情。除了大家都看過的《灌籃高手》，這裡還有更硬核、更熱血的選擇！',
        items: [
            { title: '強風吹拂', q: 'Run with the Wind', url: 'https://www.myvideo.net.tw/details/3/17384', desc: '這不是關於跑步的故事，而是關於如何在逆風中奔跑。10個性格迥異的大學生，為了箱根驛傳這個看似不可能的夢想而集結。沒有超能力，只有汗水、傷痛與真實的自我超越。' },
            { title: '排球少年!!', q: 'Haikyuu', url: 'https://www.myvideo.net.tw/search/排球少年', desc: '沒看過《排球少年》別說你懂運動番！「飛吧！」不只是口號，更是烏野高中重返榮耀的誓言。每一個配角都有血有肉，每一場比賽都讓人緊張到忘記呼吸。' },
            { title: '藍色監獄', q: 'Blue Lock', url: 'https://www.myvideo.net.tw/search/藍色監獄', desc: '比起團隊合作，這裡更強調極致的「利己主義」。為了成為世界第一的前鋒，必須踩著別人的夢想往上爬。足球版的大逃殺，重新定義了熱血。' },
            { title: '黑子的籃球', q: 'Kuroko no Basket', url: 'https://www.myvideo.net.tw/search/黑子的籃球', desc: '雖然被稱為「超能力籃球」，但那種想要打倒「奇蹟世代」的執著是真實的。光與影的配合，展現了另一種籃球的魅力。' },
            { title: '鑽石王牌', q: 'Ace of Diamond', url: 'https://www.myvideo.net.tw/search/鑽石王牌', desc: '沒有天才主角的光環，澤村榮純靠的是一步一腳印的努力與大心臟。在強豪青道高中裡，連拿到背號都是一場戰爭。' },
            { title: '飆速宅男', q: 'Yowamushi Pedal', url: 'https://www.myvideo.net.tw/search/飆速宅男', desc: '御宅族也能成為自行車選手？小野田坂道用騎淑女車練出來的高轉速，證明了熱愛就是最強的武器。' },
            { title: '足球風雲！Goal to the Future', q: 'Shoot! Goal to the Future', url: 'https://www.myvideo.net.tw/details/3/20786', desc: '經典作品的現代續篇！當過去的傳奇遇上現代的足球少年，會擦出什麼樣的火花？對於老粉絲來說是情懷，對於新觀眾來說則是熱血的傳承。' },
            { title: '網球王子', q: 'Prince of Tennis', url: 'https://www.myvideo.net.tw/details/3/31153', desc: '還需要多做介紹嗎？殺人網球的始祖！雖然現在看來充滿了超現實的招式，但那種「還差得遠呢」的自信與帥氣，依然是無可取代的經典。' },
            { title: '白領羽球部', q: 'Rymans Club', url: 'https://www.myvideo.net.tw/details/3/19321', desc: '社畜與運動員的雙重生活！描寫成年人在工作與夢想之間的平衡，比一般校園運動番多了一份現實的重量與成熟的魅力。' },
            { title: '蜻蛉高球', q: 'Tonbo', url: 'https://www.myvideo.net.tw/details/3/27046', desc: '在高爾夫這個看似優雅的運動中，隱藏著原始的野性與天賦。看著主角如何用本能去征服球場，是一種純粹的享受。' }
        ]
    },
    {
        title: '【編輯精選】異世界轉生看膩了？這10部絕對讓你耳目一新',
        slug: 'isekai-picks-unique-10',
        intro: '異世界題材氾濫，但這幾部作品用獨特的切入點打破了套路！',
        items: [
            { title: '無職轉生~到了異世界就拿出真本事~', q: 'Mushoku Tensei', url: 'https://www.myvideo.net.tw/search/無職轉生', desc: '異世界轉生的天花板。不只是開掛爽番，更是一個廢柴大叔如何在新的人生中學會負責、學會愛人的成長史詩。作畫、音樂、劇情皆為頂級。' },
            { title: 'Re:從零開始的異世界生活', q: 'Re:Zero', url: 'https://www.myvideo.net.tw/search/從零開始', desc: '沒有強大的力量，只有「死亡回歸」的痛苦。菜月昴一次次在絕望中掙扎，只為了守護重要的人。那種無力感後的反擊，最為震撼。' },
            { title: '關於我轉生變成史萊姆這檔事', q: 'That Time I Got Reincarnated as a Slime', url: 'https://www.myvideo.net.tw/search/轉生變成史萊姆', desc: '種田流與建國流的巔峰。看著利姆路如何從一隻史萊姆變成魔王，建立起魔物與人類共存的聯邦，滿足了所有模擬經營玩家的幻想。' },
            { title: '為美好的世界獻上祝福！', q: 'Konosuba', url: 'https://www.myvideo.net.tw/search/美好的世界獻上祝福', desc: '崩壞的作畫（褒義）加上全員智障的角色，造就了這部反套路的神作。它告訴你冒險不一定要帥氣，有時候無恥一點比較快樂。' },
            { title: '異世界歸來的舅舅', q: 'Isekai Ojisan', url: 'https://www.myvideo.net.tw/search/異世界歸來的舅舅', desc: '從異世界回來後的現實生活才是重點！舅舅那些在異世界遭遇的（悲慘）經歷，配上90年代SEGA遊戲宅的思維，產生了奇妙的化學反應。' },
            { title: '轉生賢者的異世界生活', q: 'My Isekai Life', url: 'https://www.myvideo.net.tw/details/3/21049', desc: '不僅是無雙，更是連史萊姆都能變成最強戰力的故事！看著主角一臉淡定地用外掛解決世界危機，有種說不出的舒壓感。' },
            { title: '轉生成蜘蛛又怎樣！', q: 'So I\'m a Spider, So What?', url: 'https://www.myvideo.net.tw/details/3/14640', desc: '轉生成魔物已經不稀奇，但轉生成最弱小的蜘蛛？女主單口相聲般的內心戲與極限求生的緊張感完美融合，絕對是異世界中的異類！' },
            { title: '異世界藥局', q: 'Parallel World Pharmacy', url: 'https://www.myvideo.net.tw/details/3/20885', desc: '不靠魔法轟炸，而是靠現代醫學知識拯救異世界！在充滿魔法的世界裡講究科學與藥理，展現了知識就是力量的真諦。' },
            { title: '異世界迷宮裡的後宮生活', q: 'Harem in the Labyrinth of Another World', url: 'https://www.myvideo.net.tw/details/3/21011', desc: '雖然標題聽起來很勸退，但其實意外地硬核？對於迷宮探索、裝備獲取以及在這個殘酷世界生存的描寫相當細膩。' },
            { title: '轉生貴族的異世界冒險錄', q: 'Chronicles of an Aristocrat Reborn in Another World', url: 'https://www.myvideo.net.tw/details/3/23245', desc: '標準的爽番配置，但爽得恰到好處！看著主角被神眷顧到過頭，無意間破壞常識的日常，是放鬆大腦的最佳選擇。' }
        ]
    },
    {
        title: '【編輯精選】生活太累？10部治癒系動畫幫你充電',
        slug: 'healing-picks-relax-10',
        intro: '放慢腳步，感受生活中的微小幸福。這些作品是給靈魂的熱湯。',
        items: [
            { title: '葬送的芙莉蓮', q: 'Frieren', url: 'https://www.myvideo.net.tw/search/葬送的芙莉蓮', desc: '在勇者死後的冒險。對於時間、記憶與情感的探討深刻而動人。淡淡的哀傷中透著溫暖，是近年來最頂級的治癒（與致鬱）神作。' },
            { title: '夏目友人帳', q: 'Natsume Yuujinchou', url: 'https://www.myvideo.net.tw/search/夏目友人帳', desc: '能夠看見妖怪的少年夏目，與保鑣貓咪老師並肩交還名字的日子。每一個妖怪都有自己的執著與寂寞，溫柔得讓人想哭。' },
            { title: '水星領航員', q: 'Aria the Animation', url: 'https://www.myvideo.net.tw/search/水星領航員', desc: '在被水覆蓋的火星上，划著貢多拉的領航員們。極致的慢活，極致的溫柔。如果天堂有動畫，大概就是這個樣子。' },
            { title: '飛翔的魔女', q: 'Flying Witch', url: 'https://www.myvideo.net.tw/search/飛翔的魔女', desc: '發生在青森的日常魔女生活。沒有毀天滅地的魔法，只有種菜、散步和偶爾發生的小奇蹟。平淡得不可思議，卻也舒服得不可思議。' },
            { title: 'SPY×FAMILY 間諜家家酒', q: 'Spy x Family', url: 'https://www.myvideo.net.tw/search/間諜家家酒', desc: '雖然是為了任務組成的虛假家庭，但那份維護彼此的心是真的。安妮亞的顏藝與可愛，是治癒全世界的特效藥。' },
            { title: '比宇宙更遠的地方', q: 'A Place Further Than The Universe', url: 'https://www.myvideo.net.tw/details/3/12704', desc: '「青春」的代名詞！四個女高中生為了去南極而踏上旅程。那種不顧一切追逐夢想的耀眼光芒，會讓你想起自己曾經也有過的衝動。準備好紙巾，這是一趟會讓你淚流滿面的旅程。' },
            { title: '房間露營△', q: 'Room Camp', url: 'https://www.myvideo.net.tw/details/3/12703', desc: '雖然只是短篇，但《搖曳露營》的精髓一點都沒少！看著她們在社辦裡胡鬧、幻想露營的樣子，瞬間就能忘記工作的煩惱。' },
            { title: '雙人單身露營', q: 'Futari Solo Camp', url: 'https://www.myvideo.net.tw/details/3/31281', desc: '不同於一群人的熱鬧，這部作品展現了「獨處」與「共處」的微妙平衡。兩個喜歡獨自露營的人，如何在保持距離的同時互相尊重，是一種成熟的大人式浪漫。' },
            { title: '異世界悠閒農家', q: 'Farming Life in Another World', url: 'https://www.myvideo.net.tw/details/3/22427', desc: '在異世界從零開始打造農場！沒有魔王要打，只有種田、蓋房子、解決村民的民生問題。看著村莊一點點繁榮起來，有種玩模擬經營遊戲的成就感。' },
            { title: '名湯「異世界溫泉」開拓記', q: 'Isekai Onsen', url: 'https://www.myvideo.net.tw/details/3/26203', desc: '溫泉就是正義！不管是人類還是異種族，在溫暖的泉水面前都是平等的。一部充滿熱氣與和諧的放鬆番。' }
        ]
    },
    {
        title: '【編輯精選】燒腦神作！10部讓你停不下來的懸疑動畫',
        slug: 'suspense-picks-thriller-10',
        intro: '猜不到的結局，反轉再反轉的劇情。請確保你有足夠的時間，因為一旦開始就停不下來！',
        items: [
            { title: '進擊的巨人', q: 'Attack on Titan', url: 'https://www.myvideo.net.tw/search/進擊的巨人', desc: '從第一集的絕望到最後一集的震撼，這是一部跨越十年、伏筆埋到地心的史詩。當你以為知道真相時，作者諫山創總會告訴你：你什麼都不知道。' },
            { title: '命運石之門', q: 'Steins;Gate', url: 'https://www.myvideo.net.tw/search/命運石之門', desc: '這是一切的開始（Everything is based on this）。前段的慢熱是為了後段的爆發，當鳳凰院凶真開始跨越世界線拯救真由理時，傳說就此誕生。' },
            { title: '夏日重現', q: 'Summer Time Rendering', url: 'https://www.myvideo.net.tw/search/夏日重現', desc: '輪迴系的最新神作。不僅智商在線，反派更是強大到讓人絕望。看著主角慎平如何利用死亡回歸的情報差進行博弈，爽度滿點。' },
            { title: '藥師少女的獨語', q: 'The Apothecary Diaries', url: 'https://www.myvideo.net.tw/search/藥師少女', desc: '身處後宮的試毒少女，用醫藥知識解開各種懸疑案件。宮廷鬥爭與推理元素的完美結合，貓貓的冷淡吐槽更是一絕。' },
            { title: '咒術迴戰', q: 'Jujutsu Kaisen', url: 'https://www.myvideo.net.tw/search/咒術迴戰', desc: '澀谷事變的絕望與死滅迴游的規則殺，咒術的戰鬥不僅是力量的碰撞，更是規則與情報的博弈。' },
            { title: '朋友遊戲', q: 'Tomodachi Game', url: 'https://www.myvideo.net.tw/details/3/31432', desc: '友情在金錢面前值多少錢？一場考驗人性的殘酷遊戲，揭露了每個人心中最黑暗的秘密。看著主角如何用瘋狂的邏輯玩弄這場遊戲，令人不寒而慄。' },
            { title: '怪物事變', q: 'Kemono Jihen', url: 'https://www.myvideo.net.tw/details/3/14624', desc: '雖然是妖怪題材，但探討的卻是關於「歸屬」與「身分」的深刻議題。在尋找父母的過程中，主角們面對的不只是怪物，還有醜惡的人心。' },
            { title: '風都偵探', q: 'Fuuto PI', url: 'https://www.myvideo.net.tw/details/3/21157', desc: '《假面騎士W》的正統續篇！如果你喜歡硬漢偵探風格與超能力犯罪的結合，這部絕對不能錯過。作畫精良，動作場面流暢，即便沒看過特攝版也能享受其中。' },
            { title: '偵探已經，死了。', q: 'The Detective Is Already Dead', url: 'https://www.myvideo.net.tw/details/3/16763', desc: '標題即是劇透，也是謎題的開始。在名偵探死去後，身為助手的男主角該如何面對留下的謎團與新的挑戰？這是一個關於失去與繼承的故事。' },
            { title: '異世界自殺突擊隊', q: 'Suicide Squad Isekai', url: 'https://www.myvideo.net.tw/details/3/27855', desc: 'DC反派穿越異世界？這本身就是個瘋狂的點子！小丑女哈莉·奎茵在這個充滿劍與魔法的世界裡依然瘋癲。動作戲爽快，美術風格獨特，是一場視覺盛宴。' }
        ]
    },
    {
        title: '【編輯精選】笑出腹肌！10部紓壓必看的搞笑動畫',
        slug: 'comedy-picks-lol-10',
        intro: '生活太苦悶？需要一點笑聲來拯救？點開這幾部，保證讓你笑到鄰居來敲門。',
        items: [
            { title: '孤獨搖滾！', q: 'Bocchi the Rock', url: 'https://www.myvideo.net.tw/details/3/21772', desc: '雖然主角有社交恐懼症，但她的內心戲和顏藝絕對是奧斯卡等級！把陰鬱的性格變成笑點，同時用頂級的音樂演出燃爆全場，這就是波奇醬的魅力。' },
            { title: '輝夜姬想讓人告白？', q: 'Kaguya-sama: Love is War', url: 'https://www.myvideo.net.tw/details/3/32347', desc: '戀愛就是戰爭！兩個高傲的天才為了讓對方先告白，無所不用其極。明明是雙向暗戀，卻能搞得像諜報片一樣緊張刺激又好笑。' },
            { title: '銀魂', q: 'Gintama', url: 'https://www.myvideo.net.tw/details/3/31733', desc: '吐槽系的頂點，毫無下限的惡搞！不管是想看熱血戰鬥還是感人故事，或者是單純的低級笑話，《銀魂》全都能滿足你。' },
            { title: '鹿乃子乃子乃子虎視眈眈', q: 'My Deer Friend Nokotan', url: 'https://www.myvideo.net.tw/details/3/27905', desc: '這在演什麼？不要問，去感受！充滿了魔性與混沌的新番，大腦放空觀看的最佳選擇。小心那些鹿，牠們無所不在。' },
            { title: '肌肉魔法使', q: 'Mashle', url: 'https://www.myvideo.net.tw/search/肌肉魔法使', desc: '在這個魔法至上的世界，主角選擇用肌肉解決一切！各種物理破防的橋段讓人笑到噴飯。哈利波特的世界觀加上**一拳超人**的設定，你說這怎麼輸？' },
            { title: '齊木楠雄的災難', q: 'Saiki K', url: 'https://www.myvideo.net.tw/search/齊木楠雄', desc: '身為超能力者，最大的願望竟然是當個普通人？想低調卻總是引來怪人的齊木楠雄，每一集的語速都快到讓你跟不上笑點。' },
            { title: '月刊少女野崎同學', q: 'Gekkan Shoujo Nozaki-kun', url: 'https://www.myvideo.net.tw/search/月刊少女', desc: '明明是戀愛番，卻比搞笑番還好笑。身高190的少女漫畫家野崎與暗戀他的佐倉，兩人之間的「誤會」與「直男操作」是最大看點。' },
            { title: '遊戲3人娘', q: 'Asobi Asobase', url: 'https://www.myvideo.net.tw/search/遊戲3人娘', desc: '封面詐欺的極致！看似清新的美少女日常，其實是顏藝與尖叫的修羅場。配音員的喉嚨大概是鐵做的吧。' },
            { title: '碧藍之海', q: 'Grand Blue', url: 'https://www.myvideo.net.tw/search/碧藍之海', desc: '這是潛水番...吧？90%的時間都在拼酒和脫衣服，只有10%在潛水。大學生活的放縱與荒謬（誇張版）都在這裡了。' },
            { title: '間諜家家酒', q: 'Spy x Family', url: 'https://www.myvideo.net.tw/search/間諜家家酒', desc: '雖然推薦過很多次，但還是要推！優雅的間諜爸爸、殺手媽媽與讀心術女兒，這個拼湊的家庭在試圖維持「普通」的過程中，產生了無數笑料。' }
        ]
    }
];

(async () => {
    try {
        console.log('🚀 Generating 5 New CORRECTED Editor\'s Pick Articles (V2.5)...');

        const insertStmt = db.prepare(`
            INSERT INTO articles (title, content, category, slug, published_at, is_pinned, image_url)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `);

        for (const article of articles) {
            console.log(`\n📄 Processing: ${article.title}`);

            // Generate content
            let contentMarkdown = `${article.intro}\n\n`;
            let firstImage = '';

            // Determine theme for text generation
            let theme = '動畫';
            if (article.title.includes('運動')) theme = '運動競技';
            if (article.title.includes('異世界')) theme = '異世界奇幻';
            if (article.title.includes('治癒')) theme = '日常治癒';
            if (article.title.includes('懸疑')) theme = '懸疑推理';
            if (article.title.includes('搞笑')) theme = '搞笑喜劇';

            for (const [index, item] of article.items.entries()) {
                console.log(`  > Item ${index + 1}: ${item.title} (Query: ${item.q})`);

                const imageUrl = await getAnimeImage(item.q);
                let localImagePath = '';

                if (imageUrl) {
                    try {
                        const filename = `pick_${article.slug}_${index + 1}_v3.jpg`; // v3 filename
                        localImagePath = await downloadImage(imageUrl, filename);
                        console.log(`    Image saved: ${localImagePath}`);
                        if (index === 0) firstImage = localImagePath;
                    } catch (e) {
                        console.error('    Image download failed:', e.message);
                    }
                } else {
                    console.warn('    No image found on Jikan.');
                }

                // Create Section Markdown
                contentMarkdown += `## ${index + 1}. ${item.title}\n\n`;
                if (localImagePath) {
                    contentMarkdown += `![${item.title}](${localImagePath})\n\n`;
                }

                contentMarkdown += `${generateLongContent(item, theme)}\n\n`;
                contentMarkdown += `${BUTTON_HTML(item.url)}\n\n`;
                contentMarkdown += `---\n\n`;
            }

            // Insert into DB
            const today = new Date().toISOString().split('T')[0];

            // Delete same slug
            db.prepare("DELETE FROM articles WHERE slug = ?").run(article.slug);

            insertStmt.run(
                article.title,
                contentMarkdown,
                '編輯精選',
                article.slug,
                today,
                1,
                firstImage || '/assets/placeholder.jpg'
            );
            console.log(`  ✅ Inserted article: ${article.title}`);
        }

        console.log('\n🎉 V2.5 Generation Complete.');
    } catch (err) {
        console.error('\n💥 FATAL ERROR:', err);
    }
})();
