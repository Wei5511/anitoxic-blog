import { getDb } from '@/lib/db';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default function AdminDashboard() {
    const db = getDb();

    // Stats
    const totalArticles = db.prepare('SELECT COUNT(*) as count FROM articles').get().count;
    const recentArticles = db.prepare('SELECT * FROM articles ORDER BY published_at DESC LIMIT 5').all();
    const pinnedCount = db.prepare('SELECT COUNT(*) as count FROM articles WHERE is_pinned = 1').get().count;

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold">概覽儀表板</h2>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm uppercase font-semibold">總文章數</h3>
                    <p className="text-4xl font-bold mt-2 text-white">{totalArticles}</p>
                </div>
                <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm uppercase font-semibold">首頁置頂</h3>
                    <p className="text-4xl font-bold mt-2 text-orange-500">{pinnedCount}</p>
                </div>
                <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm uppercase font-semibold">系統狀態</h3>
                    <p className="text-4xl font-bold mt-2 text-green-500">正常</p>
                </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
                <div className="p-6 border-b border-slate-700 flex justify-between items-center">
                    <h3 className="font-bold text-lg">最新發布文章</h3>
                    <Link href="/admin/articles" className="text-sm text-blue-400 hover:text-blue-300">查看全部 &rarr;</Link>
                </div>
                <table className="w-full text-left">
                    <thead className="bg-slate-900/50 text-slate-400 text-sm uppercase">
                        <tr>
                            <th className="p-4">標題</th>
                            <th className="p-4">分類</th>
                            <th className="p-4">發布時間</th>
                            <th className="p-4 text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700">
                        {recentArticles.map(article => (
                            <tr key={article.id} className="hover:bg-slate-700/50 transition">
                                <td className="p-4 font-medium">{article.title}</td>
                                <td className="p-4">
                                    <span className="px-2 py-1 bg-slate-700 rounded text-xs text-slate-300">
                                        {article.category}
                                    </span>
                                </td>
                                <td className="p-4 text-slate-400 text-sm">
                                    {new Date(article.published_at).toLocaleDateString('zh-TW')}
                                </td>
                                <td className="p-4 text-right">
                                    <Link href={`/admin/editor/${article.id}`} className="text-blue-400 hover:underline text-sm">
                                        編輯
                                    </Link>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
