"use client";
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function ArticleList() {
    const [articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const router = useRouter();

    useEffect(() => {
        fetchArticles();
    }, [search]);

    async function fetchArticles() {
        setLoading(true);
        try {
            const query = search ? `?search=${encodeURIComponent(search)}` : '';
            const res = await fetch(`/api/articles${query}`);
            const data = await res.json();
            setArticles(data.data || []);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    }

    async function handleDelete(id) {
        if (!confirm('確定要刪除這篇文章嗎？此操作無法復原。')) return;

        try {
            const res = await fetch(`/api/articles/${id}`, { method: 'DELETE' });
            if (res.ok) {
                fetchArticles(); // Refresh
            } else {
                alert('刪除失敗');
            }
        } catch (err) {
            alert('錯誤: ' + err.message);
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold">文章列表</h2>
                <Link href="/admin/editor/new">
                    <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-bold transition shadow-lg shadow-orange-500/20">
                        + 新增文章
                    </button>
                </Link>
            </div>

            {/* Search */}
            <div className="relative">
                <input
                    type="text"
                    placeholder="搜尋文章標題..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg py-3 px-4 text-white focus:outline-none focus:border-orange-500 transition"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
            </div>

            {/* Table */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-900/50 text-slate-400 text-sm uppercase">
                        <tr>
                            <th className="p-4 w-16">ID</th>
                            <th className="p-4">標題</th>
                            <th className="p-4">Slug</th>
                            <th className="p-4">分類</th>
                            <th className="p-4">狀態</th>
                            <th className="p-4 text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700">
                        {loading ? (
                            <tr><td colSpan="6" className="p-8 text-center text-slate-500">載入中...</td></tr>
                        ) : articles.length === 0 ? (
                            <tr><td colSpan="6" className="p-8 text-center text-slate-500">沒有找到文章</td></tr>
                        ) : (
                            articles.map(article => (
                                <tr key={article.id} className="hover:bg-slate-700/50 transition group">
                                    <td className="p-4 text-slate-500">#{article.id}</td>
                                    <td className="p-4 font-medium">
                                        <div className="flex flex-col">
                                            <span>{article.title}</span>
                                            <span className="text-xs text-slate-500 md:hidden">{new Date(article.published_at).toLocaleDateString()}</span>
                                        </div>
                                    </td>
                                    <td className="p-4 text-slate-400 font-mono text-xs">{article.slug}</td>
                                    <td className="p-4">
                                        <span className={`px-2 py-1 rounded text-xs ${article.category === '動畫介紹' ? 'bg-blue-900 text-blue-200' : 'bg-purple-900 text-purple-200'}`}>
                                            {article.category}
                                        </span>
                                    </td>
                                    <td className="p-4">
                                        {article.is_pinned === 1 && <span className="text-xs bg-orange-900 text-orange-200 px-2 py-1 rounded">置頂</span>}
                                    </td>
                                    <td className="p-4 text-right space-x-3">
                                        <Link href={`/admin/editor/${article.id}`} className="text-slate-300 hover:text-white font-medium">
                                            編輯
                                        </Link>
                                        <button
                                            onClick={() => handleDelete(article.id)}
                                            className="text-red-400 hover:text-red-300 text-sm"
                                        >
                                            刪除
                                        </button>
                                        <a href={`/articles/${article.slug}`} target="_blank" className="text-slate-500 hover:text-slate-300 text-sm">
                                            預覽
                                        </a>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
