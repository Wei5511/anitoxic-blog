/**
 * SEED v10.0 - THE FINAL POLISH
 * 
 * 1. Category Update: "集數更新" -> "動畫介紹" (for single articles).
 * 2. Link Fixes: Ensure Fire Force & MF Ghost have correct search URLs.
 * 3. Editor's Picks Overhaul: Massive articles, 500+ words per entry, with buttons.
 */

const Database = require('better-sqlite3');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'anime.db');

// --- Helper for Button HTML ---
function getBtn(url) {
    if (!url) return '';
    return `\n\n<a href="${url}" class="btn-orange-small" target="_blank">立即觀看</a>\n\n`;
}

// --- Content Generators (Recycling high-quality single article content for listicles) ---

const frierenText = `《葬送的芙莉蓮》第二季終於在萬眾矚目下歸來，正式進入原作中備受好評的「北部高原篇」。這部作品自第一季播出以來，便以其獨特的敘事節奏和對時間流逝的深刻描寫，在奇幻動畫領域佔據了一席之地。如果說第一季是芙莉蓮「了解人類」的起點，那麼第二季則是她真正深入過去回憶與現代羈絆交織的旅程。

在結束了驚險刺激的「一級魔法使考試」後，芙莉蓮、費倫與修塔爾克三人獲得了繼續前行的資格。他們的最終目的地依然未變——勇者辛美爾長眠的「魂靈沉眠之地」（オレオール）。然而，要抵達那裡，他們必須穿越被稱為大陸最危險地帶之一的「北部高原」。這裡不僅氣候嚴寒、地形險惡，更棲息著連魔法使都難以對付的高強魔物。本季的故事將聚焦於旅途中的點點滴滴與遭遇。不同於一般的冒險故事只專注於打倒敵人，本作花費了大量篇幅描寫角色們在旅途中的日常生活：在暴風雪中尋找庇護所、尋找稀有的藥草、甚至是解決路過城鎮的微小委託。

值得一提的是 Madhouse 在本季的製作依然保持了極高水準。導演斎藤圭一郎對於畫面構圖的掌控力令人驚嘆，他善於利用寬廣的風景鏡頭來表現北部高原的寂寥與壯闊，同時在細微的人物表情描寫上毫不馬乎。色彩設計上，本季大量使用了冷色調來呈現冰天雪地的氛圍，但每當營火燃起或魔法發動時，那溫暖的光影反差又極具視覺衝擊力。Evan Call 譜寫的配樂依舊是本作的靈魂，那帶有凱爾特風格的悠揚旋律，總能在最恰當的時刻響起，將觀眾的情緒推向高潮。`;

const jjkText = `隨著澀谷事變的落幕，日本社會陷入了前所未有的混亂與恐慌，而這僅僅是絕望的開始。《咒術迴戰》第三季「死滅迴游篇」以更加沉重與殘酷的基調拉開序幕。這不僅僅是另一場戰鬥，而是一場精心設計的、針對全體術師的生存遊戲。原作漫畫家芥見下下在這個篇章中展現了極大的野心，將戰鬥規則複雜化，並引入了大量極具個性的新角色，將「咒術戰」提升到了智鬥與力鬥並重的全新高度。

故事緊接著上一季的結尾，最惡詛咒師羂索啟動了名為「死滅迴游」的儀式。這是一個強制全日本覺醒術師參加的殺戮遊戲，規則冷酷無情：玩家必須透過殺死其他玩家來獲取積分，而 19 天內積分未變動者將會被術式剝奪生命。為了拯救被捲入遊戲的姐姐津美紀，以及解開封印五條悟的獄門疆，虎杖悠仁、伏黑惠決定主動參賽。與此同時，特級術師乙骨憂太也正式回歸，他在前幾集的表現將證明為何他被稱為現代最強術師的接班人。

在動畫製作方面，MAPPA 再一次挑戰了極限。死滅迴游篇的戰鬥密度極高，且場景多變，從廢棄的都市叢林到傳統的日式結界，對背景美術與攝影都是巨大考驗。製作團隊透過大膽的運鏡與動態模糊效果，完美還原了術師們高速移動與咒力碰撞的衝擊感。特別是對於「領域展開」的視覺呈現，本季採用了更加抽象與藝術化的表現手法，讓觀眾仿佛置身於角色的異質空間中。音效設計也相當出色，咒力打擊的重低音與骨骼碎裂的聲音細節，進一步強化了戰鬥的殘酷感。`;

const oshiText = `如果說《我推的孩子》前兩季是在鋪陳演藝圈的光鮮與黑暗，那麼第三季的「電影篇」就是直擊這一切核心的最終爆發。本季劇情進入了原作中情感濃度最高、也是角色衝突最激烈的篇章。阿奎亞長久以來的復仇計畫終於進入了執行階段，而他所選擇的舞台，竟然是一部描述他母親、傳奇偶像「星野愛」一生的電影——《15年的謊言》。這部作品不僅是對演藝圈的控訴，更是阿奎亞與露比兄妹對過去創傷的正面對決。

劇情的張力來自於「戲裡戲外」的虛實交錯。阿奎亞與生父神木光的對峙雖然沒有刀光劍影，但每一次對話都暗藏殺機。為了讓電影達到完美的復仇效果，阿奎亞不僅親自擔任主演，更要求露比飾演電影中的「星野愛」。對於露比來說，這意味著她必須徹底剖析母親的內心，去理解那個總是帶著完美笑容偶像背後的孤獨與脆弱。在一次次的排練中，露比被迫面對自己被遺棄的前世記憶，以及對母親複雜的愛恨交織。看著露比在崩潰邊緣掙扎並最終蛻變出驚人演技的過程，絕對會讓觀眾揪心不已。

製作方動畫工房素以細膩的角色作畫聞名，在本季中更是將這項優勢發揮到極致。角色們細微的眼神流轉、顫抖的嘴角，以及在強光照射下投射出的陰影，都被刻畫得入木三分。特別是在「戲中戲」的段落，製作組透過改變畫幅比例與色調，巧妙地區分了「現實」與「電影畫面」，營造出一種令人不安的窺視感。聲優們的表現更是令人嘆為觀止，尤其是飾演露比的聲優，在幾場情感爆發的哭戲中展現了驚人的爆發力，完美詮釋了角色內心的撕裂與重生。`;

const fireText = `由大久保篤創作的熱血少年漫畫《炎炎消防隊》，其動畫版終於迎來了最終完結篇「參之章」。這部作品自連載以來，便以其獨特的「消防員滅火」結合「超能力戰鬥」的設定吸引了大量粉絲。而隨著劇情的推進，我們發現這不僅僅是一個打倒怪物的王道故事，其背後更隱藏著關於世界起源、宗教狂熱以及人類意志的宏大哲學探討。本季作為系列的收官之作，將把這些伏筆一一回收，並帶來前所未有的超大規模戰鬥。

故事進入最終階段，反派勢力「傳道者」一派的計畫已經圖窮匕見——他們意圖再次引發曾經毀滅世界的「大災害」，將地球化為一顆燃燒的太陽。為了阻止這個瘋狂的計畫，森羅日下部所屬的第八特殊消防隊必須聯合其他隊伍，主動出擊迎戰擁有壓倒性戰力的「白衣人」。本季的核心看點在於森羅與他的家人的關係。作為擁有「亞多拉爆裂火」的柱，森羅不僅要面對強大的外部敵人，還要面對已經被洗腦成為敵方戰力的弟弟「象」，以及那位一直存在於謎團中的母親。親情的羈絆與世界的命運，兩者之間的拉扯將是森羅最後的試煉。

David Production（大衛社）的製作實力在本作中再次得到了印證。他們對於「火焰」的描繪已經達到了業界頂尖水準，不同角色的火焰根據其特性有著完全不同的質感與動態——有的如猛獸般狂野，有的如雷射般精準。配合上標誌性的具現化音效（那個低沉的重低音爆破聲），每一場打鬥都是一場視聽盛宴。導演在動作分鏡上極具創意，頻繁使用極具透視感的大廣角鏡頭來展現角色在空中高速機動的姿態，這種充滿速度感與張力的畫面語言，完美契合了本作熱血激昂的風格。`;

const mfText = `引擎的轟鳴聲是男人的浪漫，而《MF Ghost 燃油車鬥魂》正是將這份浪漫延續到了未來。作為經典賽車漫畫《頭文字D》的正統續作，本作設定在一個電動車完全普及、燃油車面臨滅絕的近未來。然而，一項名為「MFG」的賽事卻逆勢而行，堅持使用傳統燃油跑車在公路上進行競速。這不僅是為了懷舊，更是為了證明人類駕駛技術與機械工藝的極限。第三季的到來，標誌著片桐夏向的挑戰進入了全新的階段。

片桐夏向，這位師承自傳奇車手藤原拓海的英日混血天才，駕駛著馬力遠遠落後於對手的 Toyota 86 GT。在前兩季中，他憑藉著神乎其技的「慣性漂移」與對輪胎管理的極致掌控，在超跑林立的 MFG 賽場上殺出血路。第三季的舞台來到了 MFG 第三戰的舉辦地——「The Peninsula 真鶴」。真鶴賽道不同於之前的長直線高速賽道，這裡道路狹窄、彎道錯綜複雜，且高低落差極大，被稱為「技術者的天堂」。這對於馬力不足但操控靈活的 86 來說，無疑是絕佳的反擊機會。

在製作上，動畫組對於車輛的還原度依然是強項。所有的參賽車輛都經過原廠授權與監修，從引擎聲浪到排氣管的回火聲，都力求真實。尤其是當經典的 Eurobeat（歐陸節拍）BGM 響起的那一刻，那種腎上腺素飆升的快感是任何其他作品無法替代的。雖然人物作畫依然保留了重野秀一老師獨特的復古風格（這一點見仁見智），但在賽車場景的 3D 運算與速度感呈現上，本季表現得更加成熟流暢，讓觀眾彷彿真的坐在副駕駛座上體驗極速狂飆。`;

// --- Listicle Articles Data ---

const winterTop10Content = `2026 年的冬季新番陣容堪稱「神仙打架」，多部重量級續作回歸，加上話題十足的漫改新作，讓動漫迷們每週都過得充實無比。我們為大家精選了 5 部本季絕對不容錯過的頂尖作品，每一部都值得你花時間細細品味。

## 1. 葬送的芙莉蓮 第二季
![葬送的芙莉蓮](/images/anime/frieren-s2.jpg)
${frierenText}
${getBtn('https://www.myvideo.net.tw/details/3/25017')}

## 2. 咒術迴戰 死滅迴游篇
![咒術迴戰](/images/anime/jjk-culling.jpg)
${jjkText}
${getBtn('https://www.myvideo.net.tw/details/3/13256')}

## 3. 我推的孩子 第三季
![我推的孩子](/images/anime/oshi-no-ko-s3.jpg)
${oshiText}
${getBtn('https://www.myvideo.net.tw/details/3/23112')}

## 4. 炎炎消防隊 參之章
![炎炎消防隊](/images/anime/fire-force-s3.jpg)
${fireText}
${getBtn('https://www.myvideo.net.tw/search/炎炎消防隊')}

## 5. MF Ghost 燃油車鬥魂 第三季
![MF Ghost](/images/anime/mf-ghost-s3.jpg)
${mfText}
${getBtn('https://www.myvideo.net.tw/search/燃油車鬥魂')}
`;

const actionPicksContent = `喜歡腎上腺素飆升的快感嗎？本季的動作番絕對能滿足你對熱血與戰鬥渴望。以下是編輯為你精心挑選的 3 部動作大片，保證打得精彩、戰得痛快！

## 1. 咒術迴戰 死滅迴游篇
![咒術迴戰](/images/anime/jjk-culling.jpg)
${jjkText}
${getBtn('https://www.myvideo.net.tw/details/3/13256')}

## 2. 炎炎消防隊 參之章
![炎炎消防隊](/images/anime/fire-force-s3.jpg)
${fireText}
${getBtn('https://www.myvideo.net.tw/search/炎炎消防隊')}

## 3. MF Ghost 燃油車鬥魂
![MF Ghost](/images/anime/mf-ghost-s3.jpg)
${mfText}
${getBtn('https://www.myvideo.net.tw/search/燃油車鬥魂')}
`;

const listicles = [
    {
        slug: 'winter-2026-top10',
        title: '【2026冬番】5部必看動畫深度解析與完整介紹',
        content: winterTop10Content,
        category: '編輯精選'
    },
    {
        slug: 'action-picks',
        title: '【編輯精選】3部重磅熱血戰鬥番推薦',
        content: actionPicksContent,
        category: '編輯精選'
    },
    // Adding placeholder content for others to ensure valid structure
    {
        slug: 'romance-picks',
        title: '【編輯精選】年度最甜戀愛番推薦',
        category: '編輯精選',
        content: `愛情總是能治癒人心，特別是那些描寫細膩、情感真摯的優秀作品。本季有兩部風格截然不同的戀愛動畫，分別展現了青春的躁動與成熟的浪漫。

## 1. 相反的你和我
![相反的你和我](/images/anime/polar-opposites.jpg)
在充斥著異世界轉生與超能力戰鬥的動畫市場中，《相反的你和我》就像一杯清爽的檸檬蘇打水，以其純粹、真誠且甜度爆表的校園戀愛喜劇風格，迅速俘獲了觀眾的心。這部改編自阿賀澤紅茶人氣漫畫的作品，沒有複雜的後宮關係，沒有令人胃痛的誤會糾葛，只有兩個性格截然不同的人如何慢慢靠近、互相理解的溫暖過程。它證明了簡單的故事如果講得好，依然擁有打動人心的力量。

故事的女主角鈴木美優是一個為了融入群體、總是察言觀色的「辣妹系」女生，她充滿活力卻也容易感到疲憊；而男主角谷悠介則是一個戴著眼鏡、沈默寡言，堅持自我步調的「書呆子」。在一般校園劇的設定中，這樣兩人通常是平行線，但在本作中，他們卻因為座位相鄰而產生了交集。美優發現了谷隱藏在冷淡外表下的溫柔與細膩，而谷也看見了美優在隨波逐流背後的真實與可愛。
${getBtn('https://www.myvideo.net.tw/search/相反的你和我')}

## 2. 花樣少年少女
![花樣少年少女](/images/anime/game-rec.jpg)
在少女漫畫的歷史長河中，《花樣少年少女》（偷偷愛著你）絕對是佔有重要地位的經典之作。它開啟了「女扮男裝潛入男校」這一題材的黃金時代，並曾多次被改編為真人電視劇（台劇、日劇、韓劇），風靡全亞洲。如今，這部傳奇作品終於迎來了首次完整的電視動畫化。對於老粉來說，這是一次穿越時空的圓夢之旅；對於新觀眾來說，這是一次體驗純正少女漫魅力的絕佳機會。

故事的女主角蘆屋瑞稀，是一位在美國長大的日本僑生。因為在電視上看到了跳高選手佐野泉的優美身姿，被深深感動。當她得知佐野因傷放棄跳高後，毅然決然剪去長髮，隱瞞性別轉學到了佐野就讀的日本男校——櫻咲學園，並幸運（或不幸）地成為了佐野的室友。她的目標只有一個：鼓勵佐野再次回到跳高場上。
${getBtn('')}
`
    }
];

async function seed() {
    console.log('🚀 Seeding v10: The Final Polish...');
    const db = new Database(dbPath);

    // 1. Update Categories for Single Articles
    console.log('🔄 Updating categories to "動畫介紹"...');
    const singleSlugs = [
        'frieren-s2-ep1', 'jjk-culling-ep1', 'oshi-no-ko-s3-ep1',
        'fire-force-s3-ep1', 'polar-opposites-ep1', 'torture-princess-s2-ep1',
        'medalist-ep1', 'mf-ghost-s3-ep1', 'vigilantes-s2-ep1',
        'sentenced-ep1', 'darwin-ep1', 'hells-paradise-s2-ep1',
        'jojo-sbr-ep1', 'nube-ep1', 'hanakimi-ep1'
    ];

    // Also including old slugs just in case they exist
    const oldSlugs = ['frieren-ep1', 'jjk-ep1', 'oshi-no-ko-ep1'];

    const catUpdateStmt = db.prepare('UPDATE articles SET category = ? WHERE slug = ?');
    for (const slug of [...singleSlugs, ...oldSlugs]) {
        catUpdateStmt.run('動畫介紹', slug);
    }
    console.log('✅ Categories updated.');

    // 2. Fix Links (Safety Check)
    console.log('🔗 Fixing special links...');
    db.prepare('UPDATE articles SET myvideo_url = ? WHERE slug = ?')
        .run('https://www.myvideo.net.tw/search/炎炎消防隊', 'fire-force-s3-ep1');

    db.prepare('UPDATE articles SET myvideo_url = ? WHERE slug = ?')
        .run('https://www.myvideo.net.tw/search/燃油車鬥魂', 'mf-ghost-s3-ep1');
    console.log('✅ Links verified.');

    // 3. Rewrite Listicles
    console.log('📝 Rewriting Editor\'s Picks with massive content...');
    const listUpdateStmt = db.prepare('UPDATE articles SET title = ?, content = ?, category = ? WHERE slug = ?');

    for (const list of listicles) {
        const res = listUpdateStmt.run(list.title, list.content, list.category, list.slug);
        if (res.changes > 0) {
            console.log(`✅ Updated Listicle: ${list.slug} (Len: ${list.content.length})`);
        } else {
            console.log(`⚠️ Listicle not found: ${list.slug}`);
        }
    }

    console.log('\n🎉 Final Polish Complete!');
}

seed();
