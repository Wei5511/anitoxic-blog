import Link from 'next/link';

export default function AdminLayout({ children }) {
    return (
        <div className="flex min-h-screen bg-slate-900 text-slate-100 font-sans">
            {/* Sidebar */}
            <aside className="w-64 bg-slate-800 border-r border-slate-700 flex flex-col fixed h-full">
                <div className="p-6 border-b border-slate-700">
                    <h1 className="text-xl font-bold bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
                        漫性中毒 Admin
                    </h1>
                </div>

                <nav className="flex-1 p-4 space-y-2">
                    <Link href="/admin" className="block px-4 py-3 rounded hover:bg-slate-700 transition flex items-center gap-3">
                        <span>📊</span> 儀表板
                    </Link>
                    <Link href="/admin/editor/new" className="block px-4 py-3 rounded hover:bg-slate-700 transition flex items-center gap-3">
                        <span>✏️</span> 寫新文章
                    </Link>
                    <Link href="/admin/articles" className="block px-4 py-3 rounded hover:bg-slate-700 transition flex items-center gap-3">
                        <span>📝</span> 文章列表
                    </Link>
                    <Link href="/admin/banner" className="block px-4 py-3 rounded hover:bg-slate-700 transition flex items-center gap-3">
                        <span>🖼️</span> Banner 管理
                    </Link>
                    <Link href="/" target="_blank" className="block px-4 py-3 rounded hover:bg-slate-700 transition flex items-center gap-3 mt-8 border-t border-slate-700">
                        <span>🏠</span> 前往首頁
                    </Link>
                </nav>

                <div className="p-4 border-t border-slate-700 text-sm text-slate-500 text-center">
                    Admin v1.0
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 ml-64 p-8">
                <div className="max-w-7xl mx-auto">
                    {children}
                </div>
            </main>
        </div>
    );
}
