import "./globals.css";

export const metadata = {
    title: "【漫】性中毒 | Anime Addicts",
    description: "追蹤每季最新動漫，獲取即時資訊與精彩內容",
    keywords: ["動漫", "anime", "新番", "季番", "日本動畫"],
};

export default function RootLayout({ children }) {
    return (
        <html lang="zh-TW">
            <body>{children}</body>
        </html>
    );
}
